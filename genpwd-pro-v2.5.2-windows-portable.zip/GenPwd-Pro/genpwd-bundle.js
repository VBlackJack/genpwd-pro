// GenPwd Pro v2.5.1 - Build automatique 2025-11-05T14:32:23.985Z
(function() {
"use strict";

// ============================================================================
// MODULES CONSOLIDÉS (14 fichiers)
// ============================================================================

// Variables globales pour remplacer les imports/exports
const GenPwdModules = {};

// === js/config/constants.js ===
/*
 * Copyright 2025 Julien Bombled
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// src/js/config/constants.js - Toutes les constantes du projet
GenPwdModules.APP_VERSION = window.APP_VERSION = const APP_VERSION = '2.5.2';
GenPwdModules.APP_NAME = window.APP_NAME = const APP_NAME = 'GenPwd Pro';

GenPwdModules.CHAR_SETS = window.CHAR_SETS = const CHAR_SETS = Object.freeze({
  standard: Object.freeze({
    consonants: Object.freeze(['b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'z']),
    vowels: Object.freeze(['a', 'e', 'i', 'o', 'u', 'y']),
    specials: Object.freeze(['!', '#', '%', '+', ',', '-', '.', '/', ':', '=', '@', '_'])
  }),
  
  'standard-layout': Object.freeze({
    consonants: Object.freeze(['b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'n', 'p', 'r', 's', 't', 'v', 'x']),
    vowels: Object.freeze(['e', 'i', 'o', 'u', 'y']),
    specials: Object.freeze(['!', '#', '%', '+', ',', '-', '.', '/', ':', '=', '@', '_'])
  }),
  
  alphanumerique: Object.freeze({
    consonants: Object.freeze(['b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'z']),
    vowels: Object.freeze(['a', 'e', 'i', 'o', 'u', 'y']),
    specials: Object.freeze([])
  }),
  
  'alphanumerique-layout': Object.freeze({
    consonants: Object.freeze(['b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'n', 'p', 'r', 's', 't', 'v', 'x']),
    vowels: Object.freeze(['e', 'i', 'o', 'u', 'y']),
    specials: Object.freeze([])
  })
});

GenPwdModules.DIGITS = window.DIGITS = const DIGITS = Object.freeze(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']);

GenPwdModules.LEET_SUBSTITUTIONS = window.LEET_SUBSTITUTIONS = const LEET_SUBSTITUTIONS = Object.freeze({
  'a': '@', 'A': '@',
  'e': '3', 'E': '3',
  'i': '1', 'I': '1',
  'o': '0', 'O': '0',
  's': '5', 'S': '5',
  't': '7', 'T': '7',
  'l': '!', 'L': '!',
  'g': '9', 'G': '9',
  'b': '8', 'B': '8'
});

GenPwdModules.DICTIONARY_CONFIG = window.DICTIONARY_CONFIG = const DICTIONARY_CONFIG = Object.freeze({
  french: {
    url: './dictionaries/french.json',
    name: 'Français',
    flag: '🇫🇷',
    expectedCount: 800
  },
  english: {
    url: './dictionaries/english.json', 
    name: 'English',
    flag: '🇬🇧',
    expectedCount: 1000
  },
  latin: {
    url: './dictionaries/latin.json',
    name: 'Latin',
    flag: '🏛️',
    expectedCount: 500
  }
});

GenPwdModules.FALLBACK_DICTIONARY = window.FALLBACK_DICTIONARY = const FALLBACK_DICTIONARY = Object.freeze([
  "abri", "acier", "actif", "aimer", "algue", "alpes", "amande", "ananas", "ancien", "ancre",
  "angle", "animal", "arbre", "argent", "arome", "asile", "aspect", "atelier", "atlas", "atout",
  "audace", "avion", "avocat", "azimut", "bagage", "baie", "balade", "bambou", "banane", "banc",
  "barbe", "baril", "bassin", "bazar", "beige", "belier", "bento", "bisou", "bison", "bitume",
  "blason", "bleu", "bloc", "bocal", "boheme", "boite", "bonbon", "bonheur", "bosse", "botte",
  "boucle", "boue", "bougie", "boule", "branche", "bravo", "bref", "bruit", "bulle", "bureau",
  "cactus", "cadre", "caisse", "calme", "canyon", "capable", "carafe", "carbone", "cargo", "carte",
  "casque", "cave", "caviar", "ceinture", "cellule", "cerise", "chance", "chaud", "cheval", "chou",
  "ciel", "cigale", "ciment", "citron", "clair", "classe", "clic", "client", "cloche", "clou",
  "cobalt", "codage", "coeur", "coffee", "colline", "colonne", "combat", "comete", "compact", "confort",
  "copain", "corail", "corde", "cornet", "corps", "cosmos", "coton", "couche", "courbe", "courir",
  "coyote", "crabe", "cran", "crayon", "creme", "creux", "crique", "cristal", "croix", "cumulus",
  "cycle", "dague", "dalle", "danger", "danse", "dauphin", "debout", "declic", "degre", "delta",
  "demain", "dent", "desert", "dessin", "detail", "devoir", "dialogue", "diode", "disque", "dollar",
  "dragon", "droit", "dune", "duvet", "eclair", "ecorce", "ecoute", "effet", "effort", "eglise",
  "elegant", "email", "emotif", "empire", "encore", "energie", "enfant", "epice", "epoque", "equipe",
  "erable", "erreur", "espace", "esprit", "essai", "essor", "etoile", "etroit", "etude", "europe",
  "examen", "exemple", "exode", "fable", "facile", "faible", "faisan", "fakir", "fameux", "farine",
  "faune", "faute", "favori", "femelle", "fenetre", "ferme", "fibre", "figure", "filtre", "final",
  "finir", "fiole", "flamme", "floral", "flotte", "flute", "foire", "fonce", "fondre", "forage",
  "former", "fortune", "forum", "fosse", "foudre", "fraise", "franc", "frappe", "froid", "fromage",
  "front", "fruit", "fusion", "galaxie", "galet", "garage", "garcon", "garde", "gazon", "geant",
  "genial", "genome", "gentil", "geode", "gerer", "givre", "glace", "glaive", "gloire", "gomme",
  "gorge", "gouter", "grain", "gramme", "grande", "griffe", "grillon", "grotte", "groupe", "guide",
  "hasard", "havre", "hibou", "hiver", "hobby", "homard", "horizon", "huile", "humain", "humble"
]);

GenPwdModules.DEFAULT_SETTINGS = window.DEFAULT_SETTINGS = const DEFAULT_SETTINGS = Object.freeze({
  mode: 'syllables',
  qty: 5,
  mask: true,
  digitsNum: 2,
  specialsNum: 2,
  customSpecials: '_+-=.@#%',
  placeDigits: 'aleatoire',
  placeSpecials: 'aleatoire',
  caseMode: 'mixte',
  specific: {}
});

GenPwdModules.LIMITS = window.LIMITS = const LIMITS = Object.freeze({
  SYLLABLES_MIN_LENGTH: 6,
  SYLLABLES_MAX_LENGTH: 64,
  PASSPHRASE_MIN_WORDS: 2,
  PASSPHRASE_MAX_WORDS: 8,
  MIN_QUANTITY: 1,
  MAX_QUANTITY: 20,
  MIN_DIGITS: 0,
  MAX_DIGITS: 6,
  MIN_SPECIALS: 0,
  MAX_SPECIALS: 6
});

// Validation automatique des constantes
function validateCharSets() {
  for (const [key, policy] of Object.entries(CHAR_SETS)) {
    if (!Array.isArray(policy.consonants) || policy.consonants.length === 0) {
      console.error(`CHAR_SETS.${key}.consonants invalide`);
      return false;
    }
    if (!Array.isArray(policy.vowels) || policy.vowels.length === 0) {
      console.error(`CHAR_SETS.${key}.vowels invalide`);
      return false;
    }
  }
  
  // Vérification Cross-Layout
  const standardLayout = CHAR_SETS['standard-layout'];
  if (standardLayout.vowels.includes('a')) {
    console.error('"a" présent dans standard-layout - devrait être exclu');
    return false;
  }
  
  console.log('CHAR_SETS validé avec CLI-Safe + Cross-Layout');
  return true;
}

// Validation au chargement du module
if (!validateCharSets()) {
  throw new Error('Données CHAR_SETS corrompues');
}


// === js/utils/helpers.js ===
/*
 * Copyright 2025 Julien Bombled
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// src/js/utils/helpers.js - Fonctions utilitaires extraites

/**
 * Generates a cryptographically secure random integer between min and max (inclusive)
 * Uses Web Crypto API (crypto.getRandomValues) instead of Math.random() for unpredictability
 * Implements rejection sampling to avoid modulo bias
 *
 * @param {number} min - Minimum value (inclusive)
 * @param {number} max - Maximum value (inclusive)
 * @returns {number} Cryptographically secure random integer in [min, max]
 * @throws {Error} If parameters are invalid (not numbers or min > max)
 *
 * @example
 * randInt(1, 10) // → 7 (cryptographically random)
 * randInt(0, 255) // → 142 (cryptographically random)
 */
function randInt(min, max) {
  if (typeof min !== 'number' || typeof max !== 'number' || min > max) {
    throw new Error(`randInt: paramètres invalides (${min}, ${max})`);
  }

  const range = max - min + 1;

  // Special case: range is power of 2, use simple masking (more efficient)
  if ((range & (range - 1)) === 0) {
    const mask = range - 1;
    const bytes = new Uint8Array(4);
    crypto.getRandomValues(bytes);
    const value = new DataView(bytes.buffer).getUint32(0, true);
    return min + (value & mask);
  }

  // General case: rejection sampling to avoid modulo bias
  const bytesNeeded = Math.ceil(Math.log2(range) / 8);
  const maxValid = Math.floor((256 ** bytesNeeded) / range) * range;

  let randomValue;
  do {
    const randomBytes = new Uint8Array(bytesNeeded);
    crypto.getRandomValues(randomBytes);

    // Convert bytes to integer (little-endian)
    randomValue = 0;
    for (let i = 0; i < bytesNeeded; i++) {
      randomValue += randomBytes[i] * (256 ** i);
    }
  } while (randomValue >= maxValid); // Reject values that would cause bias

  return min + (randomValue % range);
}

/**
 * Selects a cryptographically secure random element from an array
 * Uses crypto.getRandomValues() via randInt() for unpredictability
 *
 * @param {Array} arr - Source array
 * @returns {*} Cryptographically secure random element from the array
 * @throws {Error} If parameter is not an array or if array is empty
 *
 * @example
 * pick(['a', 'b', 'c']) // → 'b' (cryptographically random)
 * pick([1, 2, 3, 4, 5]) // → 3 (cryptographically random)
 */
function pick(arr) {
  if (!Array.isArray(arr)) {
    console.warn(`pick() appelé avec un non-array: ${typeof arr}`);
    throw new Error(`pick: paramètre doit être un array, reçu: ${typeof arr}`);
  }
  if (arr.length === 0) {
    console.warn('pick() appelé avec un array vide');
    throw new Error('pick: tableau vide ou invalide');
  }

  // Use cryptographically secure randInt() instead of Math.random()
  return arr[randInt(0, arr.length - 1)];
}

/**
 * Ensures the input is converted to an array
 * @param {*} input - Input value (array, string, or other)
 * @returns {Array} Array representation of input
 * @example
 * ensureArray(['a', 'b']) // → ['a', 'b']
 * ensureArray('hello') // → ['h', 'e', 'l', 'l', 'o']
 * ensureArray(null) // → []
 */
function ensureArray(input) {
  if (Array.isArray(input)) {
    return input;
  }
  if (typeof input === 'string') {
    return input.split('');
  }
  return [];
}

/**
 * Clamps a percentage value between 0 and 100, rounded to 1 decimal place
 * @param {number} value - Value to clamp
 * @returns {number} Clamped percentage (0.0 - 100.0)
 * @example
 * clampPercent(150) // → 100.0
 * clampPercent(-50) // → 0.0
 * clampPercent(42.567) // → 42.6
 */
const clampPercent = (value) => {
  if (typeof value !== 'number' || Number.isNaN(value)) {
    return 0;
  }
  return Math.max(0, Math.min(100, Math.round(value * 10) / 10));
};

/**
 * Encapsulated state for placement positions
 * Prevents global scope pollution and provides controlled access
 */
const placementState = {
  digits: [],
  specials: []
};

function normalizePercentages(percentages, count) {
  if (count <= 0) {
    return [];
  }

  const sanitized = Array.isArray(percentages)
    ? percentages
        .map(value => (typeof value === 'number' ? value : parseFloat(value)))
        .filter(value => Number.isFinite(value))
        .map(clampPercent)
        .sort((a, b) => a - b)
    : [];

  if (sanitized.length >= count) {
    return sanitized.slice(0, count);
  }

  const fallback = distributeEvenly(count);
  const merged = fallback.slice();

  for (let i = 0; i < sanitized.length; i++) {
    merged[i] = sanitized[i];
  }

  return merged;
}

/**
 * Sets the digit placement positions
 * @param {Array<number>} positions - Array of percentage positions (0-100)
 * @returns {Array<number>} Normalized and sorted positions
 */
function setDigitPositions(positions) {
  placementState.digits = normalizePercentages(positions, Array.isArray(positions) ? positions.length : 0);
  return [...placementState.digits]; // Return defensive copy
}

/**
 * Sets the special character placement positions
 * @param {Array<number>} positions - Array of percentage positions (0-100)
 * @returns {Array<number>} Normalized and sorted positions
 */
function setSpecialPositions(positions) {
  placementState.specials = normalizePercentages(positions, Array.isArray(positions) ? positions.length : 0);
  return [...placementState.specials]; // Return defensive copy
}

/**
 * Gets the current digit placement positions
 * @returns {Array<number>} Copy of digit positions
 */
function getDigitPositions() {
  return [...placementState.digits]; // Return defensive copy
}

/**
 * Gets the current special character placement positions
 * @returns {Array<number>} Copy of special positions
 */
function getSpecialPositions() {
  return [...placementState.specials]; // Return defensive copy
}

/**
 * Distributes a count of points evenly across a range
 * @param {number} count - Number of points to distribute
 * @param {number} start - Start of range (default: 0)
 * @param {number} end - End of range (default: 100)
 * @returns {Array<number>} Array of evenly distributed percentage points
 * @example
 * distributeEvenly(3) // → [0, 50, 100]
 * distributeEvenly(5, 20, 80) // → [20, 35, 50, 65, 80]
 */
function distributeEvenly(count, start = 0, end = 100) {
  const safeCount = Math.max(0, parseInt(count, 10) || 0);
  if (safeCount === 0) {
    return [];
  }

  const safeStart = clampPercent(start);
  const safeEnd = clampPercent(end);
  const min = Math.min(safeStart, safeEnd);
  const max = Math.max(safeStart, safeEnd);

  if (safeCount === 1) {
    return [clampPercent((min + max) / 2)];
  }

  const step = (max - min) / (safeCount - 1);
  const points = [];

  for (let i = 0; i < safeCount; i++) {
    points.push(clampPercent(min + step * i));
  }

  return points;
}

/**
 * Inserts characters into a base string at specified percentage positions
 * @param {string} base - Base string
 * @param {Array<string>} charsToInsert - Characters to insert
 * @param {Array<number>} percentages - Percentage positions (0-100) for each character
 * @returns {string} Resulting string with inserted characters
 * @example
 * insertWithPercentages('hello', ['!', '?'], [0, 100]) // → '!hello?'
 * insertWithPercentages('hello', ['1', '2'], [50, 50]) // → 'hel12lo'
 */
/**
 * OPTIMIZED: O(n+m) complexity instead of O(n*m)
 * Builds result in single pass without repeated splices
 */
function insertWithPercentages(base, charsToInsert, percentages) {
  const baseStr = typeof base === 'string' ? base : '';
  const chars = ensureArray(charsToInsert).filter(ch => typeof ch === 'string');

  if (chars.length === 0) {
    return baseStr;
  }

  if (baseStr.length === 0) {
    return chars.join('');
  }

  const positions = normalizePercentages(percentages, chars.length);
  const baseLength = baseStr.length;

  // Calculate absolute insertion positions
  const insertions = positions.map((percent, index) => ({
    pos: Math.max(0, Math.min(baseLength, Math.round((percent / 100) * baseLength))),
    char: chars[index],
    originalIndex: index
  }))
  .filter(item => typeof item.char === 'string')
  .sort((a, b) => a.pos - b.pos || a.originalIndex - b.originalIndex);

  // Build result in single pass - O(n+m) complexity
  let result = '';
  let baseIndex = 0;
  let insertionIndex = 0;

  while (baseIndex < baseLength || insertionIndex < insertions.length) {
    // Insert all characters that belong at current position
    while (insertionIndex < insertions.length && insertions[insertionIndex].pos === baseIndex) {
      result += insertions[insertionIndex].char;
      insertionIndex++;
    }

    // Add character from base string
    if (baseIndex < baseLength) {
      result += baseStr[baseIndex];
      baseIndex++;
    }
  }

  return result;
}

/**
 * Insère des caractères dans une chaîne selon un mode de placement
 * @param {string} base - Chaîne de base
 * @param {Array|string} charsToInsert - Caractères à insérer
 * @param {string} placement - Mode de placement ('debut', 'fin', 'milieu', 'aleatoire', 'positions')
 * @param {Object} [options={}] - Options supplémentaires
 * @param {Array<number>} [options.percentages] - Pourcentages de placement (si placement='positions')
 * @param {string} [options.type] - Type de caractères ('digits', 'specials')
 * @returns {string} Chaîne résultante avec les caractères insérés
 * @example
 * insertWithPlacement('abc', ['1', '2'], 'fin') // → 'abc12'
 * insertWithPlacement('abc', ['1', '2'], 'debut') // → '12abc'
 * insertWithPlacement('abc', ['1', '2'], 'aleatoire') // → 'a1b2c' (exemple)
 */
function insertWithPlacement(base, charsToInsert, placement, options = {}) {
  if (typeof base !== 'string') base = '';

  const chars = ensureArray(charsToInsert)
    .map(c => (typeof c === 'string' ? c : String(c ?? '')))
    .filter(c => c.length > 0);

  if (chars.length === 0) return base;
  if (base.length === 0) return chars.join('');

  if (placement === 'positions') {
    const { percentages, type } = options || {};
    let percentList = Array.isArray(percentages) ? percentages : null;

    if (!percentList) {
      if (type === 'digits') {
        percentList = getDigitPositions();
      } else if (type === 'specials') {
        percentList = getSpecialPositions();
      }
    }

    if (percentList && percentList.length > 0) {
      return insertWithPercentages(base, chars, percentList);
    }

    placement = 'aleatoire';
  }

  if (placement === 'debut') {
    return chars.join('') + base;
  }

  if (placement === 'fin') {
    return base + chars.join('');
  }

  const arr = base.split('');
  const insertAt = (pos, ch) => {
    const safePos = Math.max(0, Math.min(arr.length, pos));
    arr.splice(safePos, 0, ch);
  };

  try {
    switch (placement) {
      case 'debut':
        for (let i = chars.length - 1; i >= 0; i--) {
          insertAt(0, chars[i]);
        }
        break;
      case 'milieu': {
        let mid = Math.floor(arr.length / 2);
        chars.forEach(ch => {
          insertAt(mid, ch);
          mid++;
        });
        break;
      }
      default: // aleatoire
        chars.forEach(ch => {
          insertAt(randInt(0, arr.length), ch);
        });
    }
  } catch (e) {
    // Log error properly instead of silently masking it
    console.error(`Error in insertWithPlacement: ${e.message}`, {
      placement,
      charsLength: chars.length,
      baseLength: base.length,
      error: e
    });
    // Return safe fallback
    return base + chars.join('');
  }

  return arr.join('');
}

/**
 * Counts the composition of characters in a string
 * @param {string} str - Input string
 * @returns {Object} Object with counts: { U: uppercase, L: lowercase, D: digits, S: special }
 * @example
 * compositionCounts('Hello123!') // → { U: 1, L: 4, D: 3, S: 1 }
 */
function compositionCounts(str) {
  if (typeof str !== 'string') return { U: 0, L: 0, D: 0, S: 0 };
  
  let U = 0, L = 0, D = 0, S = 0;
  for (const ch of str) {
    if (/[A-Z]/.test(ch)) U++;
    else if (/[a-z]/.test(ch)) L++;
    else if (/[0-9]/.test(ch)) D++;
    else S++;
  }
  return { U, L, D, S };
}

/**
 * Escapes HTML special characters in a string
 * @param {string} str - Input string
 * @returns {string} HTML-escaped string
 * @example
 * escapeHtml('<script>alert("XSS")</script>') // → '&lt;script&gt;alert(&quot;XSS&quot;)&lt;/script&gt;'
 */
function escapeHtml(str) {
  if (typeof str !== 'string') return '';
  return str.replace(/[&<>"']/g, m => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[m]));
}

/**
 * Calculates the base-2 logarithm of a number
 * @param {number} n - Input number (must be > 0)
 * @returns {number} Log base 2 of n, or 0 if n <= 0
 * @example
 * log2(8) // → 3
 * log2(256) // → 8
 */
function log2(n) {
  if (typeof n !== 'number' || n <= 0) return 0;
  return Math.log(n) / Math.log(2);
}


// === js/utils/logger.js ===
/*
 * Copyright 2025 Julien Bombled
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// src/js/utils/logger.js - Système de logs sécurisé
const MAX_LOG_LINES = 100;
const LOG_TRIM_SIZE = 50;

function nowTime() {
  const d = new Date();
  return [d.getHours(), d.getMinutes(), d.getSeconds()]
    .map(n => String(n).padStart(2, '0'))
    .join(':');
}

function safeLog(msg) {
  console.log('LOG:', msg);
  
  requestAnimationFrame(() => {
    const el = document.getElementById('logs');
    if (!el) return;

    try {
      if (el.textContent.trim() === '[--:--:--] En attente d\'initialisation...') {
        el.textContent = '';
      }

      const newLine = `[${nowTime()}] ${msg}\n`;
      el.textContent += newLine;

      const lines = el.textContent.split('\n');
      if (lines.length > MAX_LOG_LINES) {
        el.textContent = lines.slice(-LOG_TRIM_SIZE).join('\n');
        el.textContent = `[${nowTime()}] ...logs précédents tronqués...\n` + el.textContent;
      }

      el.scrollTop = el.scrollHeight;
    } catch (e) {
      console.error('Erreur dans safeLog:', e);
    }
  });
}

function clearLogs() {
  const logsEl = document.getElementById('logs');
  if (logsEl) {
    logsEl.textContent = '';
    safeLog('Logs effacés');
  }
}


// === js/utils/toast.js ===
/*
 * Copyright 2025 Julien Bombled
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// src/js/utils/toast.js - Système de notifications temporaires
const activeToasts = new Set();

function showToast(message, type = 'info') {
  const wrap = document.getElementById('toasts');
  if (!wrap) return;

  try {
    const div = document.createElement('div');
    div.className = 'toast';
    div.style.cssText = `
      position: fixed; top: ${20 + activeToasts.size * 60}px; right: 20px; z-index: 1000;
      background: var(--bg-secondary); color: var(--text-primary);
      padding: 12px 16px; border-radius: 8px; border: 1px solid var(--border);
      box-shadow: var(--shadow); margin-bottom: 8px; max-width: 320px;
      border-left: 4px solid ${type === 'error' ? 'var(--accent-red)' : 
                             type === 'success' ? 'var(--accent-green)' : 'var(--accent-blue)'};
      opacity: 1; transform: translateX(0); transition: all 0.3s ease;
    `;
    div.textContent = message;
    
    activeToasts.add(div);
    wrap.appendChild(div);

    const cleanup = () => {
      activeToasts.delete(div);
      if (div.parentNode) div.remove();
    };

    setTimeout(() => {
      if (div.parentNode) {
        div.style.opacity = '0';
        div.style.transform = 'translateX(20px)';
      }
    }, 3200);

    setTimeout(cleanup, 3600);
  } catch (e) {
    console.error('Erreur toast:', e);
  }
}


// === js/utils/clipboard.js ===
/*
 * Copyright 2025 Julien Bombled
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// src/js/utils/clipboard.js - Gestion sécurisée du presse-papiers

async function copyToClipboard(text) {
  if (!text) return false;

  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
    
    return fallbackCopyTextToClipboard(text);
  } catch (err) {
    safeLog(`Erreur copie clipboard: ${err.message}`);
    return fallbackCopyTextToClipboard(text);
  }
}

function fallbackCopyTextToClipboard(text) {
  try {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    
    Object.assign(textArea.style, {
      position: 'fixed',
      top: '0',
      left: '0',
      width: '2em',
      height: '2em',
      padding: '0',
      border: 'none',
      outline: 'none',
      boxShadow: 'none',
      background: 'transparent',
      opacity: '0'
    });

    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    const successful = document.execCommand('copy');
    document.body.removeChild(textArea);
    
    return successful;
  } catch (err) {
    safeLog(`Erreur fallback clipboard: ${err.message}`);
    return false;
  }
}


// === js/core/dictionaries.js ===
/*
 * Copyright 2025 Julien Bombled
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// src/js/core/dictionaries.js - Système de dictionnaires multilingues




const REMOTE_PROTOCOL_REGEX = /^https?:\/\//i;
const DICTIONARY_LOAD_TIMEOUT = DICTIONARY.LOAD_TIMEOUT;

async function loadDictionarySource(config) {
  const { url } = config;

  const isBrowserContext = typeof window !== 'undefined' && typeof window.fetch === 'function';
  const shouldUseHttpFetch = isBrowserContext || REMOTE_PROTOCOL_REGEX.test(url);

  if (shouldUseHttpFetch) {
    // Create AbortController for timeout mechanism
    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
      controller.abort();
      safeLog(`Dictionary load timeout after ${DICTIONARY_LOAD_TIMEOUT}ms: ${url}`);
    }, DICTIONARY_LOAD_TIMEOUT);

    try {
      const response = await fetch(url, {
        method: 'GET',
        signal: controller.signal, // Link fetch to AbortController
        headers: {
          'Accept': 'application/json',
          'Cache-Control': 'public, max-age=3600'
        }
      });

      clearTimeout(timeoutId); // Cancel timeout on success

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      return response.json();

    } catch (error) {
      clearTimeout(timeoutId); // Cancel timeout on error

      // Distinguish between timeout and other errors
      if (error.name === 'AbortError') {
        throw new Error(`Dictionary load timeout after ${DICTIONARY_LOAD_TIMEOUT}ms: ${url}`);
      }

      throw error;
    }
  }

  const [{ readFile }, nodePath, { fileURLToPath }] = await Promise.all([
    import('node:fs/promises'),
    import('node:path'),
    import('node:url')
  ]);

  const normalizedPath = url.startsWith('./') ? url.slice(2) : url;
  const cwd = typeof globalThis.process?.cwd === 'function' ? globalThis.process.cwd() : null;
  const moduleDir = nodePath.dirname(fileURLToPath(import.meta.url));

  const candidatePaths = [
    nodePath.resolve(moduleDir, '../../', normalizedPath)
  ];

  if (cwd) {
    candidatePaths.unshift(
      nodePath.resolve(cwd, 'src', normalizedPath)
    );
    candidatePaths.unshift(
      nodePath.resolve(cwd, normalizedPath)
    );
  }

  let lastError = null;

  for (const candidate of candidatePaths) {
    try {
      const fileContent = await readFile(candidate, 'utf-8');
      safeLog(`Lecture locale du dictionnaire ${config.name} depuis ${candidate}`);
      return JSON.parse(fileContent);
    } catch (error) {
      if (error.code !== 'ENOENT') {
        throw error;
      }
      lastError = error;
    }
  }

  throw lastError || new Error(`Impossible de localiser le dictionnaire ${url}`);
}

// État interne du système de dictionnaires
const dictionaries = {
  current: 'french',
  cache: new Map(),
  status: new Map()
};

async function loadDictionary(dictKey) {
  if (!DICTIONARY_CONFIG[dictKey]) {
    throw new Error(`Dictionnaire "${dictKey}" non configuré`);
  }

  // Vérifier le cache
  if (dictionaries.cache.has(dictKey)) {
    const cached = dictionaries.cache.get(dictKey);
    if (Array.isArray(cached) && cached.length > 0) {
      safeLog(`Dictionnaire ${dictKey} trouvé en cache (${cached.length} mots)`);
      return cached;
    }
  }

  const config = DICTIONARY_CONFIG[dictKey];
  updateDictionaryStatus(dictKey, 'loading');
  
  try {
    safeLog(`Chargement du dictionnaire ${dictKey} depuis ${config.url}`);

    const data = await loadDictionarySource(config);

    // Integrity validation (if hash is configured)
    if (typeof data === 'string' || data instanceof ArrayBuffer) {
      const integrityResult = await validateDictionary(dictKey, data);
      if (!integrityResult.valid) {
        // Determine if we're in production (HTTPS + non-localhost)
        const isProd = typeof location !== 'undefined' &&
                       location.protocol === 'https:' &&
                       !location.hostname.includes('localhost') &&
                       !location.hostname.includes('127.0.0.1');

        if (isProd) {
          // In production, fail hard on integrity violations
          throw new Error(`Dictionary integrity check FAILED: ${integrityResult.message}`);
        } else {
          // In development, log warning but continue
          safeLog(`⚠️ DEV MODE: ${integrityResult.message}`);
        }
      } else if (!integrityResult.skipped) {
        safeLog(`✓ ${integrityResult.message}`);
      }
    }

    // Validation du format
    if (!data || !Array.isArray(data.words)) {
      throw new Error('Format de dictionnaire invalide (propriété "words" manquante)');
    }

    const words = data.words.filter(word => 
      typeof word === 'string' && 
      word.length >= 3 && 
      word.length <= 12 &&
      /^[a-zA-ZàâäéèêëïîôöùûüÿñçæœÀÂÄÉÈÊËÏÎÔÖÙÛÜŸÑÇÆŒ]+$/.test(word)
    );

    if (words.length === 0) {
      throw new Error('Aucun mot valide trouvé dans le dictionnaire');
    }

    // Mise en cache
    dictionaries.cache.set(dictKey, words);
    updateDictionaryStatus(dictKey, 'loaded', words.length);
    
    safeLog(`Dictionnaire ${dictKey} chargé: ${words.length} mots validés`);
    
    // Mettre à jour les infos UI
    updateDictionaryInfo(dictKey, words.length, data.metadata);
    
    return words;
    
  } catch (error) {
    safeLog(`Erreur chargement dictionnaire ${dictKey}: ${error.message}`);
    updateDictionaryStatus(dictKey, 'error');
    updateDictionaryInfo(dictKey, 0, null, error.message);
    
    // Fallback vers le dictionnaire français intégré
    if (dictKey !== 'french') {
      safeLog('Fallback vers dictionnaire français intégré');
      updateDictionaryStatus(dictKey, 'fallback');
      updateDictionaryInfo(dictKey, FALLBACK_DICTIONARY.length, null, 'Utilisation du fallback français');
      return FALLBACK_DICTIONARY;
    }
    
    throw error;
  }
}

async function getCurrentDictionary(dictKey = null) {
  const targetDict = dictKey || dictionaries.current;
  
  try {
    return await loadDictionary(targetDict);
  } catch (error) {
    safeLog(`Impossible de charger le dictionnaire ${targetDict}, utilisation du fallback`);
    return FALLBACK_DICTIONARY;
  }
}

function setCurrentDictionary(dictKey) {
  if (DICTIONARY_CONFIG[dictKey]) {
    dictionaries.current = dictKey;
    safeLog(`Dictionnaire courant changé vers: ${dictKey}`);
  }
}

function updateDictionaryStatus(dictKey, status, count = null) {
  const statusEl = document.getElementById('dict-status');
  if (!statusEl) return;

  dictionaries.status.set(dictKey, { status, count, timestamp: Date.now() });

  statusEl.className = `dict-status ${status}`;
  
  switch (status) {
    case 'loading':
      statusEl.textContent = '⏳';
      break;
    case 'loaded':
      statusEl.textContent = '✓';
      break;
    case 'error':
      statusEl.textContent = '✗';
      break;
    case 'fallback':
      statusEl.textContent = '🇫🇷';
      break;
    default:
      statusEl.textContent = '--';
  }
}

function updateDictionaryInfo(dictKey, count, metadata = null, error = null) {
  const infoEl = document.getElementById('dict-info');
  if (!infoEl) return;

  if (error) {
    infoEl.textContent = `Erreur: ${error}`;
    infoEl.style.color = 'var(--accent-red)';
  } else if (count > 0) {
    const version = metadata?.version || 'v1.0';
    const source = metadata?.source || 'inconnu';
    infoEl.textContent = `${count} mots • ${version} • Source: ${source}`;
    infoEl.style.color = 'var(--text-muted)';
  } else {
    infoEl.textContent = 'Aucun mot disponible';
    infoEl.style.color = 'var(--accent-yellow)';
  }
}

function initializeDictionaries() {
  // Initialiser le fallback français
  updateDictionaryStatus('french', 'fallback');
  updateDictionaryInfo('french', FALLBACK_DICTIONARY.length, 
    { version: 'v1.0', source: 'intégré' });
  
  safeLog('Système de dictionnaires initialisé');
}


// === js/core/casing.js ===
/*
 * Copyright 2025 Julien Bombled
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// src/js/core/casing.js - Gestion de la casse et système de blocs

/**
 * Applies case transformation to a string
 * @param {string} str - Input string
 * @param {string} mode - Case mode: 'upper', 'lower', 'title', 'mixte'
 * @returns {string} Transformed string with applied case mode
 * @example
 * applyCase('hello', 'upper') // → 'HELLO'
 * applyCase('HELLO', 'lower') // → 'hello'
 * applyCase('hello world', 'title') // → 'Hello World'
 * applyCase('hello', 'mixte') // → 'HeLlO' (cryptographically random case)
 */
function applyCase(str, mode) {
  if (typeof str !== 'string') return '';

  switch (mode) {
    case 'upper':
      return str.toUpperCase();

    case 'lower':
      return str.toLowerCase();

    case 'title':
      return str.split(/(\P{L})/u).map(seg =>
        /\p{L}+/u.test(seg) ?
        seg.charAt(0).toUpperCase() + seg.slice(1).toLowerCase() :
        seg
      ).join('');

    default: // mixte - CRYPTOGRAPHICALLY SECURE
      return str.split('').map(ch => {
        if (!/\p{L}/u.test(ch)) return ch;

        // Use crypto.getRandomValues() instead of Math.random() for security
        const randomByte = new Uint8Array(1);
        crypto.getRandomValues(randomByte);
        const isUpper = (randomByte[0] & 1) === 1; // Use LSB for random boolean

        return isUpper ? ch.toUpperCase() : ch.toLowerCase();
      }).join('');
  }
}

/**
 * Applies a case pattern to a string using block tokens
 * @param {string} str - Input string
 * @param {Array<string>} tokens - Array of case tokens ('U', 'l', 'T')
 * @param {Object} opts - Options
 * @param {boolean} opts.perWord - Apply pattern per word instead of per character
 * @param {boolean} opts.syllableMode - Apply pattern every 3 letters (syllable mode)
 * @returns {string} String with applied case pattern
 * @example
 * applyCasePattern('hello', ['U', 'l'], {}) // → 'HeLlO'
 * applyCasePattern('hello world', ['T', 'l'], { perWord: true }) // → 'Hello world'
 */
function applyCasePattern(str, tokens, opts = {}) {
  if (typeof str !== 'string' || !Array.isArray(tokens) || tokens.length === 0) {
    return str || '';
  }

  const perWord = Boolean(opts.perWord);
  const syllableMode = Boolean(opts.syllableMode);

  const isLetterChar = (char) => typeof char === 'string' && /\p{L}/u.test(char);

  let idx = 0, out = '', prev = '', letterCount = 0;
  let wordIndex = 0;

  for (const ch of str) {
    const isLetter = isLetterChar(ch);
    const isWordStart = isLetter && !isLetterChar(prev);

    if (perWord && isWordStart) {
      idx = wordIndex % tokens.length;
      wordIndex++;
    } else if (syllableMode && isLetter && letterCount > 0 && letterCount % 3 === 0) {
      idx = (idx + 1) % tokens.length;
    }

    if (isLetter) {
      const t = tokens[idx % tokens.length];
      if (t === 'U') out += ch.toUpperCase();
      else if (t === 'l') out += ch.toLowerCase();
      else if (t === 'T') out += isWordStart ? ch.toUpperCase() : ch.toLowerCase();
      else out += ch;
      letterCount++;

      if (!perWord && !syllableMode) {
        idx = (idx + 1) % tokens.length;
      }
    } else {
      out += ch;
    }
    prev = ch;
  }
  return out;
}

/**
 * Calculates the appropriate number of case blocks based on mode and parameter
 * @param {string} mode - Generation mode (syllables, passphrase, leet)
 * @param {number} param - Mode-specific parameter (length for syllables, word count for passphrase)
 * @returns {number} Number of blocks to generate (1-50)
 * @example
 * calculateBlocksCount('syllables', 20) // → 6
 * calculateBlocksCount('passphrase', 5) // → 5
 */
function calculateBlocksCount(mode, param = 20) {
  if (mode === 'syllables') {
    return Math.max(1, Math.min(10, Math.floor(param / 3)));
  } else if (mode === 'passphrase') {
    return Math.max(2, Math.min(8, parseInt(param) || 5));
  } else if (mode === 'leet') {
    const length = typeof param === 'number' ? param : parseInt(param, 10);
    return Math.max(1, Math.min(50, Number.isFinite(length) ? length : 0));
  }
  return 2;
}

/**
 * Generates default case blocks for a given mode
 * @param {string} mode - Generation mode (syllables, passphrase, leet)
 * @param {number} param - Mode-specific parameter
 * @returns {Array<string>} Array of case block tokens
 * @example
 * defaultBlocksForMode('syllables', 20) // → ['U', 'l', 'l', 'l', 'l', 'l']
 * defaultBlocksForMode('passphrase', 5) // → ['T', 'l', 'l', 'l', 'l']
 */
function defaultBlocksForMode(mode, param = 20) {
  const count = calculateBlocksCount(mode, param);
  if (mode === 'syllables') {
    const tokens = [];
    for (let i = 0; i < count; i++) {
      tokens.push(i === 0 ? 'U' : 'l');
    }
    return tokens;
  } else if (mode === 'passphrase') {
    const tokens = [];
    for (let i = 0; i < count; i++) {
      tokens.push(i === 0 ? 'T' : 'l');
    }
    return tokens;
  } else if (mode === 'leet') {
    const tokens = [];
    for (let i = 0; i < count; i++) {
      tokens.push(i === 0 ? 'T' : 'l');
    }
    return tokens;
  }
  return ['T', 'l'];
}

/**
 * Generates randomized case blocks for a given mode
 * Uses cryptographically secure pick() function
 * @param {string} mode - Generation mode (syllables, passphrase, leet)
 * @param {number} param - Mode-specific parameter
 * @returns {Array<string>} Array of random case block tokens
 * @example
 * randomizeBlocks('syllables', 20) // → ['U', 'T', 'l', 'U', 'l', 'T'] (random)
 * randomizeBlocks('passphrase', 5) // → ['l', 'U', 'T', 'l', 'U'] (random)
 */
function randomizeBlocks(mode, param = 20) {
  const count = calculateBlocksCount(mode, param);
  const options = ['U', 'l', 'T'];
  const tokens = [];
  
  for (let i = 0; i < count; i++) {
    tokens.push(pick(options));
  }
  
  return tokens;
}


// === js/core/generators.js ===
/*
 * Copyright 2025 Julien Bombled
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// src/js/core/generators.js - Logique principale de génération





const CLI_SAFE_SPECIAL_SET = new Set(CHAR_SETS.standard.specials);
const DANGEROUS_CHARS = new Set(['$', '^', '&', '*', "'"]);

GenPwdModules.sanitizeSpecialCandidates = window.sanitizeSpecialCandidates = function sanitizeSpecialCandidates(candidates) {
  const unique = [];
  for (const candidate of candidates) {
    if (typeof candidate !== 'string' || candidate.length === 0) {
      continue;
    }

    const char = candidate[0];
    if (!CLI_SAFE_SPECIAL_SET.has(char)) {
      continue;
    }

    if (!unique.includes(char)) {
      unique.push(char);
    }
  }
  return unique;
}

GenPwdModules.enforceCliSafety = window.enforceCliSafety = function enforceCliSafety(value, context) {
  if (typeof value !== 'string') {
    return;
  }

  for (const dangerous of DANGEROUS_CHARS) {
    if (value.includes(dangerous)) {
      throw new Error(`SECURITE: Caractère ${dangerous} détecté dans ${context}`);
    }
  }
}

/**
 * Génère un mot de passe basé sur des syllabes (alternance consonnes/voyelles)
 * @param {Object} config - Configuration de génération
 * @param {number} config.length - Longueur du mot de passe (lettres uniquement, avant ajout chiffres/spéciaux)
 * @param {string} config.policy - Politique de caractères ('standard', 'standard-layout', 'alphanumerique', 'alphanumerique-layout')
 * @param {number} config.digits - Nombre de chiffres à ajouter (0-6)
 * @param {number} config.specials - Nombre de caractères spéciaux à ajouter (0-6)
 * @param {string|Array} config.customSpecials - Caractères spéciaux personnalisés (optionnel)
 * @param {string} config.placeDigits - Position des chiffres ('debut', 'fin', 'milieu', 'aleatoire', 'positions')
 * @param {string} config.placeSpecials - Position des spéciaux ('debut', 'fin', 'milieu', 'aleatoire', 'positions')
 * @param {string} config.caseMode - Mode de casse ('mixte', 'minuscule', 'majuscule', 'title', 'blocks')
 * @param {boolean} config.useBlocks - Utiliser le système de blocs de casse
 * @param {Array<string>} config.blockTokens - Tokens de blocs ['U', 'l', 'T'] (si useBlocks=true)
 * @returns {Object} Résultat contenant { value: string, entropy: number, mode: string, policy: string }
 * @throws {Error} Si la politique n'existe pas ou si les paramètres sont invalides
 * @example
 * const result = generateSyllables({
 *   length: 20,
 *   policy: 'standard',
 *   digits: 2,
 *   specials: 2,
 *   placeDigits: 'aleatoire',
 *   placeSpecials: 'fin',
 *   caseMode: 'mixte'
 * });
 * // → { value: 'duNokUpYg!aKuKYMaci5@', entropy: 103.4, mode: 'syllables', policy: 'standard' }
 */
GenPwdModules.generateSyllables = window.generateSyllables = function generateSyllables(config) {
  try {
    const { length, policy, digits, specials, customSpecials,
            placeDigits, placeSpecials, caseMode, useBlocks, blockTokens } = config;

    const policyData = CHAR_SETS[policy];
    if (!policyData) {
      throw new Error(`Politique "${policy}" non trouvée`);
    }

    const { consonants, vowels } = policyData;
    const requestedLetters = Math.max(1, length - (digits + specials));
    const letters = [];
    let nextIsConsonant = true;

    // Génération alternée consonnes/voyelles
    for (let i = 0; i < requestedLetters; i++) {
      const pool = nextIsConsonant ? consonants : vowels;
      letters.push(pick(pool));
      nextIsConsonant = !nextIsConsonant;
    }

    let core = letters.join('');

    // Application de la casse
    core = useBlocks && blockTokens?.length > 0 
      ? applyCasePattern(core, blockTokens, { syllableMode: true })
      : applyCase(core, caseMode);

    // Ajout des chiffres et caractères spéciaux
    const digitChars = Array.from({ length: digits }, () => pick(DIGITS));
    const specialPool = resolveSpecialPool(customSpecials, policy);
    const specialChars = Array.from({ length: specials }, () => pick(specialPool));

    const result = mergeWithInsertions(core, {
      chars: digitChars,
      placement: placeDigits,
      type: 'digits'
    }, {
      chars: specialChars,
      placement: placeSpecials,
      type: 'specials'
    });

    enforceCliSafety(result, 'generateSyllables');

    const entropyConfig = { ...config, mode: 'syllables' };
    const entropy = calculateEntropy('syllables', entropyConfig, result);

    return {
      value: result,
      entropy,
      mode: 'syllables',
      policy
    };

  } catch (error) {
    safeLog(`Erreur generateSyllables: ${error.message}`);
    return {
      value: `error-syllables-${Date.now()}`,
      entropy: 10,
      mode: 'syllables'
    };
  }
}

/**
 * Génère une passphrase basée sur des mots de dictionnaire
 * @param {Object} config - Configuration de génération
 * @param {number} config.wordCount - Nombre de mots dans la passphrase (2-8)
 * @param {string} config.separator - Séparateur entre les mots (ex: '-', ' ', '')
 * @param {number} config.digits - Nombre de chiffres à ajouter (0-6)
 * @param {number} config.specials - Nombre de caractères spéciaux à ajouter (0-6)
 * @param {string|Array} config.customSpecials - Caractères spéciaux personnalisés (optionnel)
 * @param {string} config.placeDigits - Position des chiffres ('debut', 'fin', 'milieu', 'aleatoire', 'positions')
 * @param {string} config.placeSpecials - Position des spéciaux ('debut', 'fin', 'milieu', 'aleatoire', 'positions')
 * @param {string} config.caseMode - Mode de casse ('mixte', 'minuscule', 'majuscule', 'title', 'blocks')
 * @param {boolean} config.useBlocks - Utiliser le système de blocs de casse
 * @param {Array<string>} config.blockTokens - Tokens de blocs ['U', 'l', 'T'] (si useBlocks=true)
 * @param {string} config.dictionary - Langue du dictionnaire ('french', 'english', 'latin')
 * @param {Array<string>} [config.wordListOverride] - Liste de mots personnalisée (optionnel)
 * @returns {Promise<Object>} Résultat contenant { value: string, entropy: number, mode: string, dictionary: string, words: Array<string> }
 * @throws {Error} Si le dictionnaire ne peut pas être chargé
 * @example
 * const result = await generatePassphrase({
 *   wordCount: 5,
 *   separator: '-',
 *   digits: 2,
 *   specials: 1,
 *   dictionary: 'french',
 *   caseMode: 'title'
 * });
 * // → { value: 'Pizza-Ideal-Mais-Petale-Fendre6@', entropy: 115.2, mode: 'passphrase', words: ['Pizza', 'Ideal', ...] }
 */
GenPwdModules.generatePassphrase = window.generatePassphrase = async function generatePassphrase(config) {
  try {
    const { wordCount, separator, digits, specials, customSpecials,
            placeDigits, placeSpecials, caseMode, useBlocks, blockTokens, dictionary,
            wordListOverride } = config;

    const sanitizedSeparator = typeof separator === 'string' ? separator : '';
    const overrideWords = Array.isArray(wordListOverride)
      ? wordListOverride.filter(word => typeof word === 'string' && word.length > 0)
      : null;

    const dictionaryWords = overrideWords && overrideWords.length > 0
      ? overrideWords
      : await getCurrentDictionary(dictionary);

    const selectedWords = overrideWords && overrideWords.length >= wordCount
      ? overrideWords.slice(0, wordCount)
      : Array.from({ length: wordCount }, () => pick(dictionaryWords));

    const validBlocks = Array.isArray(blockTokens)
      ? blockTokens.filter(token => ['U', 'l', 'T'].includes(token))
      : [];

    const shouldUseBlocks = useBlocks && validBlocks.length > 0;
    const fallbackCaseMode = caseMode === 'blocks' ? 'title' : caseMode;
    const joined = selectedWords.join(sanitizedSeparator);

    let core;
    let displayedWords;

    if (shouldUseBlocks) {
      if (sanitizedSeparator.length > 0) {
        core = applyCasePattern(joined, validBlocks, { perWord: true });
        displayedWords = core.split(sanitizedSeparator);
      } else {
        displayedWords = selectedWords.map((word, index) => {
          const token = validBlocks[index % validBlocks.length];
          return applyCasePattern(word, [token]);
        });
        core = displayedWords.join('');
      }
    } else {
      core = applyCase(joined, fallbackCaseMode);
      displayedWords = sanitizedSeparator.length > 0
        ? core.split(sanitizedSeparator)
        : selectedWords.slice();
    }

    // Ajout des chiffres et caractères spéciaux
    const digitChars = Array.from({ length: digits }, () => pick(DIGITS));
    const specialPool = resolveSpecialPool(customSpecials, config.policy || 'standard');
    const specialChars = Array.from({ length: specials }, () => pick(specialPool));

    const result = mergeWithInsertions(core, {
      chars: digitChars,
      placement: placeDigits,
      type: 'digits'
    }, {
      chars: specialChars,
      placement: placeSpecials,
      type: 'specials'
    });

    enforceCliSafety(result, 'generatePassphrase');

    const dictionarySize = (dictionaryWords && dictionaryWords.length) || 1;
    const entropyConfig = {
      ...config,
      mode: 'passphrase',
      wordCount,
      dictSize: dictionarySize,
      sepChoices: config.sepChoices ?? 1,
      policy: config.policy || 'standard'
    };
    const entropy = calculateEntropy('passphrase', entropyConfig, result);

    return {
      value: result,
      entropy,
      mode: 'passphrase',
      dictionary,
      words: displayedWords
    };

  } catch (error) {
    safeLog(`Erreur generatePassphrase: ${error.message}`);
    return {
      value: `error-passphrase-${Date.now()}`,
      entropy: 15,
      mode: 'passphrase'
    };
  }
}

/**
 * Génère un mot de passe en leet speak (substitution de lettres par des symboles/chiffres)
 * @param {Object} config - Configuration de génération
 * @param {string} config.baseWord - Mot de base à transformer en leet speak
 * @param {number} config.digits - Nombre de chiffres à ajouter (0-6)
 * @param {number} config.specials - Nombre de caractères spéciaux à ajouter (0-6)
 * @param {string|Array} config.customSpecials - Caractères spéciaux personnalisés (optionnel)
 * @param {string} config.placeDigits - Position des chiffres ('debut', 'fin', 'milieu', 'aleatoire', 'positions')
 * @param {string} config.placeSpecials - Position des spéciaux ('debut', 'fin', 'milieu', 'aleatoire', 'positions')
 * @param {string} config.caseMode - Mode de casse ('mixte', 'minuscule', 'majuscule', 'title', 'blocks')
 * @param {boolean} config.useBlocks - Utiliser le système de blocs de casse
 * @param {Array<string>} config.blockTokens - Tokens de blocs ['U', 'l', 'T'] (si useBlocks=true)
 * @returns {Object} Résultat contenant { value: string, entropy: number, mode: string, baseWord: string }
 * @example
 * const result = generateLeet({
 *   baseWord: 'password',
 *   digits: 2,
 *   specials: 1,
 *   placeDigits: 'fin',
 *   placeSpecials: 'debut'
 * });
 * // → { value: '@p@55w0rd42', entropy: 45.6, mode: 'leet', baseWord: 'password' }
 * // Transformations: a→@, s→5, o→0
 */
GenPwdModules.generateLeet = window.generateLeet = function generateLeet(config) {
  try {
    const { baseWord, digits, specials, customSpecials,
            placeDigits, placeSpecials, caseMode, useBlocks, blockTokens } = config;

    let core = applyLeetTransformation(baseWord);

    // Application de la casse
    core = useBlocks && blockTokens?.length > 0
      ? applyCasePattern(core, blockTokens, { perWord: false })
      : applyCase(core, caseMode);

    // Ajout des chiffres et caractères spéciaux
    const digitChars = Array.from({ length: digits }, () => pick(DIGITS));
    const specialPool = resolveSpecialPool(customSpecials, config.policy || 'standard');
    const specialChars = Array.from({ length: specials }, () => pick(specialPool));

    const result = mergeWithInsertions(core, {
      chars: digitChars,
      placement: placeDigits,
      type: 'digits'
    }, {
      chars: specialChars,
      placement: placeSpecials,
      type: 'specials'
    });

    enforceCliSafety(result, 'generateLeet');

    const entropyConfig = { ...config, mode: 'leet', policy: config.policy || 'standard' };
    const entropy = calculateEntropy('leet', entropyConfig, result);

    return {
      value: result,
      entropy,
      mode: 'leet',
      baseWord
    };

  } catch (error) {
    safeLog(`Erreur generateLeet: ${error.message}`);
    return {
      value: `error-leet-${Date.now()}`,
      entropy: 8,
      mode: 'leet'
    };
  }
}


GenPwdModules.mergeWithInsertions = window.mergeWithInsertions = function mergeWithInsertions(core, digitsConfig, specialsConfig) {
  let result = core;

  const applyStep = (step) => {
    if (!step || !Array.isArray(step.chars) || step.chars.length === 0) {
      return;
    }

    const options = {};
    if (step.type) {
      options.type = step.type;
    }

    if (Array.isArray(step.percentages) && step.percentages.length > 0) {
      options.percentages = step.percentages;
    }

    result = insertWithPlacement(result, step.chars, step.placement, options);
  };

  const digitsPlacement = digitsConfig?.placement;
  const specialsPlacement = specialsConfig?.placement;

  const sameSide = digitsPlacement && digitsPlacement === specialsPlacement;
  const stackOrder = sameSide && (digitsPlacement === 'fin' || digitsPlacement === 'debut')
    ? [specialsConfig, digitsConfig]
    : [digitsConfig, specialsConfig];

  stackOrder.forEach(applyStep);

  return result;
}

GenPwdModules.calculateEntropy = window.calculateEntropy = function calculateEntropy(mode, config, result) {
  const LOG2 = Math.log2;

  if (mode === 'passphrase') {
    const { wordCount, dictSize } = config;
    let entropy = (wordCount || 0) * LOG2(dictSize || 2429);

    if (config.sepChoices > 1) {
      entropy += Math.max(0, (wordCount || 0) - 1) * LOG2(config.sepChoices);
    }

    if (config.digits > 0) entropy += config.digits * LOG2(10);
    if (config.specials > 0) {
      const specialsSetSize = getSpecialsSetSize(config.policy);
      entropy += config.specials * LOG2(specialsSetSize);
    }

    return Math.round(entropy * 10) / 10;
  }

  const alphabetSize = calculatePolicyAlphabetSize(config);
  const entropy = result.length * LOG2(alphabetSize || 1);
  return Math.round(entropy * 10) / 10;
}

GenPwdModules.calculatePolicyAlphabetSize = window.calculatePolicyAlphabetSize = function calculatePolicyAlphabetSize(config) {
  let size = 0;
  const policy = CHAR_SETS[config.policy || 'standard'];

  if (policy?.consonants) size += policy.consonants.length;
  if (policy?.vowels) size += policy.vowels.length;
  if (config.digits > 0) size += 10;

  if (config.specials > 0) {
    const resolved = resolveSpecialPool(config.customSpecials, config.policy || 'standard');
    size += resolved.length;
  }

  return size;
}

GenPwdModules.getSpecialsSetSize = window.getSpecialsSetSize = function getSpecialsSetSize(policy) {
  const policyData = CHAR_SETS[policy || 'standard'];
  const specials = policyData?.specials || [];
  return specials.length > 0 ? specials.length : 12;
}

GenPwdModules.ensureMinimumEntropy = window.ensureMinimumEntropy = async function ensureMinimumEntropy(generatorFn, config, minBits = 100) {
  let result = generatorFn(config);

  if (result && typeof result.then === 'function') {
    result = await result;
  }

  let extraEntropy = 0;
  let baseEntropy = calculateEntropy(config.mode, config, result.value);
  let currentEntropy = config.mode === 'passphrase'
    ? baseEntropy + extraEntropy
    : baseEntropy;

  let attempts = 0;
  while (currentEntropy < minBits && attempts < 5) {
    const needed = Math.ceil((minBits - currentEntropy) / Math.log2(74));
    const topUp = generateRandomString(needed, '!#%+,-./:=@_0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');

    result.value += topUp;
    if (config.mode === 'passphrase') {
      extraEntropy += needed * Math.log2(74);
    }

    baseEntropy = calculateEntropy(config.mode, config, result.value);
    currentEntropy = config.mode === 'passphrase'
      ? baseEntropy + extraEntropy
      : baseEntropy;
    attempts++;
  }

  result.entropy = config.mode === 'passphrase'
    ? Math.round(currentEntropy * 10) / 10
    : currentEntropy;

  enforceCliSafety(result.value, `ensureMinimumEntropy(${config.mode})`);
  return result;
}

GenPwdModules.generateRandomString = window.generateRandomString = function generateRandomString(length, alphabet) {
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  return Array.from(array, byte => alphabet[byte % alphabet.length]).join('');
}

GenPwdModules.applyLeetTransformation = window.applyLeetTransformation = function applyLeetTransformation(word) {
  return word.split('').map(char => LEET_SUBSTITUTIONS[char] || char).join('');
}

GenPwdModules.resolveSpecialPool = window.resolveSpecialPool = function resolveSpecialPool(customSpecials, policyKey = 'standard') {
  if (Array.isArray(customSpecials) && customSpecials.length > 0) {
    const sanitizedArray = sanitizeSpecialCandidates(customSpecials);
    if (sanitizedArray.length > 0) {
      return sanitizedArray;
    }
  }

  if (typeof customSpecials === 'string' && customSpecials.length > 0) {
    const rawChars = Array.from(new Set(customSpecials.split('')));
    const sanitizedString = sanitizeSpecialCandidates(rawChars);
    if (sanitizedString.length > 0) {
      return sanitizedString;
    }
  }

  const policyData = CHAR_SETS[policyKey];
  if (policyData && Array.isArray(policyData.specials)) {
    const sanitizedPolicy = sanitizeSpecialCandidates(policyData.specials);
    return sanitizedPolicy;
  }

  const fallback = sanitizeSpecialCandidates(CHAR_SETS.standard.specials);
  return fallback;
}


// === js/config/settings.js ===
/*
 * Copyright 2025 Julien Bombled
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// src/js/config/settings.js - Gestion de l'état et validation


// État global de l'application
const AppState = {
  settings: { ...DEFAULT_SETTINGS },
  results: [],
  blocks: ['T', 'l'],
  ui: {
    debugVisible: false,
    blockDirty: false,
    useBlocks: false,
    blockAutoSync: true
  },
  cache: {
    domElements: new Map(),
    lastPreview: ''
  }
};

function validateSettings(settings) {
  const safe = {
    mode: ['syllables', 'passphrase', 'leet'].includes(settings.mode) ? settings.mode : 'syllables',
    qty: Math.max(LIMITS.MIN_QUANTITY, Math.min(LIMITS.MAX_QUANTITY, parseInt(settings.qty) || 5)),
    mask: Boolean(settings.mask),
    digitsNum: Math.max(LIMITS.MIN_DIGITS, Math.min(LIMITS.MAX_DIGITS, parseInt(settings.digitsNum) || 0)),
    specialsNum: Math.max(LIMITS.MIN_SPECIALS, Math.min(LIMITS.MAX_SPECIALS, parseInt(settings.specialsNum) || 0)),
    customSpecials: typeof settings.customSpecials === 'string' ? 
      settings.customSpecials.slice(0, 20) : '',
    placeDigits: ['debut', 'fin', 'milieu', 'aleatoire', 'positions'].includes(settings.placeDigits) ?
      settings.placeDigits : 'aleatoire',
    placeSpecials: ['debut', 'fin', 'milieu', 'aleatoire', 'positions'].includes(settings.placeSpecials) ?
      settings.placeSpecials : 'aleatoire',
    caseMode: ['mixte', 'upper', 'lower', 'title', 'blocks'].includes(settings.caseMode) ? 
      settings.caseMode : 'mixte',
    specific: {}
  };

  // Validation spécifique par mode
  if (safe.mode === 'syllables') {
    safe.specific.length = Math.max(LIMITS.SYLLABLES_MIN_LENGTH, 
      Math.min(LIMITS.SYLLABLES_MAX_LENGTH, parseInt(settings.specific?.length) || 20));
    safe.specific.policy = Object.keys(CHAR_SETS).includes(settings.specific?.policy) ? 
      settings.specific.policy : 'standard';
  } else if (safe.mode === 'passphrase') {
    safe.specific.count = Math.max(LIMITS.PASSPHRASE_MIN_WORDS, 
      Math.min(LIMITS.PASSPHRASE_MAX_WORDS, parseInt(settings.specific?.count) || 5));
    safe.specific.sep = ['-', '_', '.', ' '].includes(settings.specific?.sep) ? 
      settings.specific.sep : '-';
    safe.specific.dictionary = Object.keys(DICTIONARY_CONFIG).includes(settings.specific?.dictionary) ?
      settings.specific.dictionary : 'french';
  } else if (safe.mode === 'leet') {
    safe.specific.word = typeof settings.specific?.word === 'string' ? 
      settings.specific.word.slice(0, 50).replace(/[^\w]/g, '') || 'password' : 'password';
  }

  return safe;
}

function readSettings() {
  try {
    const rawSettings = {
      mode: getElementValue('#mode-select', 'syllables'),
      qty: getElementValue('#qty', '5'),
      mask: getElementChecked('#mask-toggle', true),
      digitsNum: getElementValue('#digits-count', '2'),
      specialsNum: getElementValue('#specials-count', '2'),
      customSpecials: getElementValue('#custom-specials', ''),
      placeDigits: getElementValue('#place-digits', 'aleatoire'),
      placeSpecials: getElementValue('#place-specials', 'aleatoire'),
      caseMode: getElementValue('#case-mode-select', 'mixte'),
      specific: {}
    };

    // Paramètres spécifiques selon le mode
    if (rawSettings.mode === 'syllables') {
      rawSettings.specific.length = getElementValue('#syll-len', '20');
      rawSettings.specific.policy = getElementValue('#policy-select', 'standard');
    } else if (rawSettings.mode === 'passphrase') {
      rawSettings.specific.count = getElementValue('#pp-count', '5');
      rawSettings.specific.sep = getElementValue('#pp-sep', '-');
      rawSettings.specific.dictionary = getElementValue('#dict-select', 'french');
    } else if (rawSettings.mode === 'leet') {
      rawSettings.specific.word = getElementValue('#leet-input', 'password');
    }

    const validSettings = validateSettings(rawSettings);
    if (validSettings.mode === 'syllables') {
      const policySelect = document.querySelector('#policy-select');
      if (policySelect && policySelect.options) {
        const options = Array.from(policySelect.options);
        const fallback = options.find(option => option.value === 'standard')?.value
          || options[0]?.value
          || 'standard';
        const desired = options.some(option => option.value === validSettings.specific.policy)
          ? validSettings.specific.policy
          : fallback;
        if (desired && policySelect.value !== desired) {
          policySelect.value = desired;
        }
      }
    }

    AppState.settings = { ...validSettings, caseBlocks: AppState.blocks.slice() };

    return AppState.settings;
  } catch (e) {
    safeLog(`Erreur readSettings: ${e.message}`);
    return AppState.settings;
  }
}

function getElementValue(selector, defaultValue) {
  const el = document.querySelector(selector);
  return el ? el.value : defaultValue;
}

function getElementChecked(selector, defaultValue) {
  const el = document.querySelector(selector);
  return el ? el.checked : defaultValue;
}

// Getters/Setters pour l'état
function getSettings() {
  return AppState.settings;
}

function setSettings(settings) {
  AppState.settings = validateSettings(settings);
}

function getResults() {
  return AppState.results;
}

function setResults(results) {
  AppState.results = Array.isArray(results) ? results : [];
}

function getBlocks() {
  return AppState.blocks;
}

function setBlocks(blocks) {
  if (Array.isArray(blocks) && blocks.length > 0) {
    AppState.blocks = blocks.filter(b => ['U', 'l', 'T'].includes(b));
    if (AppState.blocks.length === 0) {
      AppState.blocks = ['T', 'l'];
    }
  }
}

function getUIState(key) {
  if (typeof key === 'string') {
    return AppState.ui[key];
  }

  return AppState.ui;
}

function setUIState(key, value) {
  if (typeof key === 'string') {
    AppState.ui[key] = value;
  }
}

// Cache DOM
function getCachedElement(selector) {
  if (AppState.cache.domElements.has(selector)) {
    const cached = AppState.cache.domElements.get(selector);
    if (cached && document.contains(cached)) {
      return cached;
    }
    AppState.cache.domElements.delete(selector);
  }
  
  const element = document.querySelector(selector);
  if (element) {
    AppState.cache.domElements.set(selector, element);
  }
  
  return element;
}

function clearCache() {
  AppState.cache.domElements.clear();
  AppState.cache.lastPreview = '';
}


// === js/ui/dom.js ===
/*
 * Copyright 2025 Julien Bombled
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// src/js/ui/dom.js - Utilitaires DOM optimisés


function getElement(selector, useCache = true) {
  if (!selector) return null;
  
  try {
    if (useCache) {
      return getCachedElement(selector);
    }
    
    if (selector.startsWith('#')) {
      return document.getElementById(selector.slice(1));
    } else {
      return document.querySelector(selector);
    }
  } catch (e) {
    safeLog(`Erreur sélecteur DOM: ${selector} - ${e.message}`);
    return null;
  }
}

function getAllElements(selector) {
  try {
    return Array.from(document.querySelectorAll(selector));
  } catch (e) {
    safeLog(`Erreur querySelectorAll: ${selector} - ${e.message}`);
    return [];
  }
}

function addEventListener(element, event, handler, options = {}) {
  if (!element || typeof handler !== 'function') return false;
  
  try {
    element.addEventListener(event, handler, options);
    return true;
  } catch (e) {
    safeLog(`Erreur addEventListener: ${e.message}`);
    return false;
  }
}

function updateBadgeForInput(input) {
  if (!input) return;
  try {
    const badge = input.parentNode ? input.parentNode.querySelector('.badge') : null;
    if (badge) badge.textContent = input.value;
  } catch (e) {
    safeLog(`Erreur updateBadgeForInput: ${e.message}`);
  }
}

function updateVisibilityByMode() {
  const mode = getElement('#mode-select')?.value || 'syllables';
  
  const syllEl = getElement('#mode-syllables-opts');
  if (syllEl) syllEl.style.display = (mode === 'syllables') ? '' : 'none';
  
  const ppEl = getElement('#mode-passphrase-opts');
  if (ppEl) ppEl.style.display = (mode === 'passphrase') ? '' : 'none';
  
  const leetEl = getElement('#mode-leet-opts');
  if (leetEl) leetEl.style.display = (mode === 'leet') ? '' : 'none';
  
  safeLog(`Mode affiché: ${mode}`);
}

function ensureBlockVisible() {
  try {
    const caseModeSelect = getElement('#case-mode-select');
    const currentValue = caseModeSelect ? caseModeSelect.value : null;
    const show = currentValue === 'blocks';

    const row = getElement('#blocks-editor-row');
    const prev = getElement('#case-preview-row');

    if (row) row.style.display = show ? '' : 'none';
    if (prev) prev.style.display = show ? '' : 'none';
  } catch (e) {
    safeLog('ensureBlockVisible error: ' + (e?.message || e));
  }
}

function showModal(modalSelector) {
  const modal = getElement(modalSelector);
  if (modal) {
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
    
    // Focus management
    const closeBtn = modal.querySelector('.modal-close');
    if (closeBtn) closeBtn.focus();
  }
}

function hideModal(modalSelector) {
  const modal = getElement(modalSelector);
  if (modal) {
    modal.classList.remove('show');
    document.body.style.overflow = '';
  }
}

function toggleDebugPanel() {
  const debugPanel = getElement('#debug-panel');
  if (!debugPanel) return;

  const isVisible = debugPanel.style.display !== 'none';
  debugPanel.style.display = isVisible ? 'none' : 'block';

  const btn = getElement('#btn-toggle-debug');
  if (btn) {
    btn.textContent = isVisible ? '🔬 Debug' : '🔬 Fermer';
  }

  return !isVisible;
}

function renderChips(containerSelector, blocks, onChipClick) {
  const container = getElement(containerSelector);
  if (!container) return;

  container.innerHTML = '';

  blocks.forEach((token, index) => {
    const chip = document.createElement('button');
    chip.className = 'chip ' + (token === 'U' ? '' : token === 'l' ? 'chip-muted' : 'chip-title');
    chip.textContent = token;
    chip.title = 'Cliquer pour changer (U → l → T → U)';
    
    if (onChipClick) {
      addEventListener(chip, 'click', () => onChipClick(index));
    }
    
    container.appendChild(chip);
  });
}

function updateBlockSizeLabel(labelSelector, blocksCount) {
  const label = getElement(labelSelector);
  if (label) {
    label.textContent = `Blocs: ${blocksCount}`;
  }
}

async function initializeDOM() {
  try {
    // Vérifier éléments critiques
    const criticalElements = [
      '#mode-select',
      '#qty',
      '#results-list',
      '#btn-generate',
      '#logs'
    ];

    for (const selector of criticalElements) {
      const element = getElement(selector);
      if (!element) {
        throw new Error(`Élément critique manquant: ${selector}`);
      }
    }

    // Initialiser les badges des sliders
    getAllElements('input[type="range"]').forEach(updateBadgeForInput);
    
    // Initialiser la visibilité selon le mode
    updateVisibilityByMode();
    ensureBlockVisible();
    
    safeLog('DOM initialisé avec succès');
    
  } catch (error) {
    throw new Error(`Erreur initialisation DOM: ${error.message}`);
  }
}


// === js/ui/events.js ===
/*
 * Copyright 2025 Julien Bombled
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// src/js/ui/events.js - Gestion centralisée des événements
// Référence: getElement, getAllElements, addEventListener, updateBadgeForInput,
         updateVisibilityByMode, ensureBlockVisible, toggleDebugPanel,
         renderChips, updateBlockSizeLabel 










let previewTimeout = null;
let blockSyncTimeout = null;
const BLOCK_SYNC_DELAY = 200;

// Rate limiting configuration for password generation
const GENERATION_CONFIG = RATE_LIMITING;

// State for rate limiting
const generationState = {
  lastGeneration: 0,
  burstCount: 0
};

/**
 * Cleans up all active timeouts and event handlers
 * Should be called on page unload to prevent memory leaks
 */
function cleanupEventHandlers() {
  if (previewTimeout) {
    clearTimeout(previewTimeout);
    previewTimeout = null;
  }
  if (blockSyncTimeout) {
    clearTimeout(blockSyncTimeout);
    blockSyncTimeout = null;
  }
  safeLog('Event handlers cleaned up');
}

function bindEventHandlers() {
  try {
    bindMainActions();
    bindModeAndSettings();
    bindSliders();
    bindCaseAndBlocks();
    bindDebugActions();

    initializeBlockSyncState();

    const placementApi = initVisualPlacement();
    if (placementApi && typeof placementApi.onUpdate === 'function') {
      placementApi.onUpdate(() => debouncedUpdatePreview());
    }

    // Register cleanup handler for page unload
    window.addEventListener('beforeunload', cleanupEventHandlers);

    safeLog('Événements bindés avec succès');
  } catch (error) {
    throw new Error(`Erreur binding événements: ${error.message}`);
  }
}

function bindMainActions() {
  // Action principale : générer
  addEventListener(getElement('#btn-generate'), 'click', generatePasswords);
  
  // Actions secondaires
  addEventListener(getElement('#btn-copy-all'), 'click', copyAllPasswords);
  addEventListener(getElement('#btn-export'), 'click', exportPasswords);
  addEventListener(getElement('#btn-clear'), 'click', clearResults);
  
  // Actions debug
  addEventListener(getElement('#btn-run-tests'), 'click', runTests);
  addEventListener(getElement('#btn-toggle-debug'), 'click', () => {
    const isVisible = toggleDebugPanel();
    setUIState('debugVisible', isVisible);
  });
  addEventListener(getElement('#btn-clear-logs'), 'click', clearLogs);
}

function bindModeAndSettings() {
  // Changement de mode
  addEventListener(getElement('#mode-select'), 'change', (event) => {
    updateVisibilityByMode();

    const caseModeValue = getElement('#case-mode-select')?.value;
    const programmatic = event?.isTrusted === false;
    const shouldResyncBlocks = caseModeValue === 'blocks'
      && (programmatic || !getUIState().blockDirty);

    if (shouldResyncBlocks) {
      setUIState('blockDirty', false);
      resetBlocksForCurrentMode();
      scheduleCurrentModeBlockSync();
    }

    debouncedUpdatePreview();
  });

  const policySelect = getElement('#policy-select');
  if (policySelect) {
    ensurePolicySelection(policySelect);
    addEventListener(policySelect, 'change', (event) => {
      ensurePolicySelection(event?.target);
      debouncedUpdatePreview();
    });
  }

  // Masquage
  addEventListener(getElement('#mask-toggle'), 'change', () => {
    const masked = getElement('#mask-toggle').checked;
    updateMaskDisplay(masked);
    safeLog('Masquage ' + (masked ? 'activé' : 'désactivé'));
  });
  
  // Dictionnaire
  addEventListener(getElement('#dict-select'), 'change', async (e) => {
    const newDict = e.target.value;
    setCurrentDictionary(newDict);
    safeLog(`Changement dictionnaire vers: ${newDict}`);

    try {
      // Le chargement est géré par le système de dictionnaires
      showToast(`Dictionnaire ${newDict} sélectionné !`, 'success');
    } catch (error) {
      showToast(`Erreur dictionnaire ${newDict}`, 'error');
    }
  });

  addEventListener(getElement('#leet-input'), 'input', () => {
    if (getElement('#case-mode-select')?.value === 'blocks' && !getUIState().blockDirty) {
      resetBlocksForCurrentMode();
    }
    debouncedUpdatePreview();
  });
}

function bindSliders() {
  // Mise à jour des badges pour tous les sliders
  getAllElements('input[type="range"]').forEach(updateBadgeForInput);

  function handleSliderChange(e) {
    const target = e.target;
    if (target && target.type === 'range') {
      updateBadgeForInput(target);

      if (['syll-len', 'digits-count', 'specials-count', 'pp-count'].includes(target.id)) {
        debouncedUpdatePreview();

        // Réajuster les blocs si mode blocks et pas modifié manuellement
        const programmatic = e?.isTrusted === false;
        if (getElement('#case-mode-select')?.value === 'blocks'
          && (programmatic || !getUIState().blockDirty)) {
          if (programmatic) {
            setUIState('blockDirty', false);
          }
          resetBlocksForCurrentMode();
        }

        if (target.id === 'syll-len') {
          scheduleBlockSync('syllables', parseInt(target.value, 10));
        } else if (target.id === 'pp-count') {
          scheduleBlockSync('passphrase', parseInt(target.value, 10));
        }
      }
    }
  }

  document.addEventListener('input', handleSliderChange, { passive: true });
  document.addEventListener('change', handleSliderChange, { passive: true });

  // Changements qui triggent la préview
  addEventListener(getElement('#pp-sep'), 'change', debouncedUpdatePreview);
}

function bindCaseAndBlocks() {
  // Changement mode de casse
  addEventListener(getElement('#case-mode-select'), 'change', (event) => {
    ensureBlockVisible();
    const isBlocks = event.target.value === 'blocks';
    const programmatic = event?.isTrusted === false;

    setUIState('useBlocks', isBlocks);

    if (isBlocks && (programmatic || !getUIState().blockDirty)) {
      setUIState('blockDirty', false);
      resetBlocksForCurrentMode();
      scheduleCurrentModeBlockSync();
    }

    if (!isBlocks) {
      setUIState('blockDirty', false);
    }

    debouncedUpdatePreview();
  });

  const syncToggle = getElement('#blocks-sync-toggle');
  if (syncToggle) {
    addEventListener(syncToggle, 'change', (event) => {
      const enabled = Boolean(event.target.checked);
      setUIState('blockAutoSync', enabled);
      if (enabled) {
        setUIState('blockDirty', false);
        scheduleCurrentModeBlockSync();
      }
    });
  }

  // Contrôles des blocs
  addEventListener(getElement('#btn-all-title'), 'click', () => {
    const blocks = getBlocks().map(() => 'T');
    setBlocks(blocks);
    setUIState('blockDirty', true);
    renderBlocksUI();
    debouncedUpdatePreview();
  });

  addEventListener(getElement('#btn-all-upper'), 'click', () => {
    const blocks = getBlocks().map(() => 'U');
    setBlocks(blocks);
    setUIState('blockDirty', true);
    renderBlocksUI();
    debouncedUpdatePreview();
  });

  addEventListener(getElement('#btn-all-lower'), 'click', () => {
    const blocks = getBlocks().map(() => 'l');
    setBlocks(blocks);
    setUIState('blockDirty', true);
    renderBlocksUI();
    debouncedUpdatePreview();
  });

  addEventListener(getElement('#btn-block-dec'), 'click', () => {
    const blocks = getBlocks();
    if (blocks.length > 1) {
      blocks.pop();
      setBlocks(blocks);
      setUIState('blockDirty', true);
      renderBlocksUI();
      debouncedUpdatePreview();
    }
  });

  addEventListener(getElement('#btn-block-inc'), 'click', () => {
    const blocks = getBlocks();
    if (blocks.length < 10) {
      const last = blocks[blocks.length - 1];
      const next = last === 'U' ? 'l' : last === 'l' ? 'T' : 'U';
      blocks.push(next);
      setBlocks(blocks);
      setUIState('blockDirty', true);
      renderBlocksUI();
      debouncedUpdatePreview();
    }
  });

  addEventListener(getElement('#btn-block-random'), 'click', () => {
    const settings = readSettings();
    let param = 20;
    
    if (settings.mode === 'syllables') {
      param = parseInt(getElement('#syll-len')?.value || '20', 10);
    } else if (settings.mode === 'passphrase') {
      param = parseInt(getElement('#pp-count')?.value || '5', 10);
    }
    
    const randomBlocks = randomizeBlocks(settings.mode, param);
    setBlocks(randomBlocks);
    setUIState('blockDirty', true);
    renderBlocksUI();
    debouncedUpdatePreview();
    showToast('Blocs randomisés !', 'success');
  });
}

function bindDebugActions() {
  // Modal à propos
  addEventListener(getElement('#btn-about'), 'click', () => {
    const modal = getElement('#about-modal');
    if (modal) modal.classList.add('show');
  });
  
  addEventListener(getElement('#modal-close'), 'click', () => {
    const modal = getElement('#about-modal');
    if (modal) modal.classList.remove('show');
  });
  
  // Fermeture modal par overlay
  addEventListener(getElement('#about-modal'), 'click', (e) => {
    if (e.target === e.currentTarget) {
      const modal = getElement('#about-modal');
      if (modal) modal.classList.remove('show');
    }
  });
  
  // Fermeture modal par Escape
  addEventListener(document, 'keydown', (e) => {
    if (e.key === 'Escape') {
      const modal = getElement('#about-modal');
      if (modal && modal.classList.contains('show')) {
        modal.classList.remove('show');
      }
    }
  });
}

// Actions principales - REFACTORED for better maintainability

/**
 * Logs visual placement state if active
 */
function logVisualPlacement() {
  const placementState = getVisualPlacement();
  if (placementState?.mode === 'visual') {
    const digitsInfo = placementState.digits.length > 0
      ? placementState.digits.join(', ')
      : 'aucun';
    const specialsInfo = placementState.specials.length > 0
      ? placementState.specials.join(', ')
      : 'aucun';
    safeLog(`Placement visuel actif → chiffres: [${digitsInfo}] • spéciaux: [${specialsInfo}]`);
  }
}

/**
 * Builds common configuration for all generation modes
 * @param {Object} settings - Current settings
 * @returns {Object} Common configuration object
 */
function buildCommonConfig(settings) {
  return {
    digits: settings.digitsNum,
    specials: settings.specialsNum,
    customSpecials: settings.customSpecials,
    placeDigits: settings.placeDigits,
    placeSpecials: settings.placeSpecials,
    caseMode: settings.caseMode,
    useBlocks: settings.caseMode === 'blocks',
    blockTokens: getBlocks()
  };
}

/**
 * Generates a single password based on mode
 * @param {string} mode - Generation mode (syllables, passphrase, leet)
 * @param {Object} commonConfig - Common configuration
 * @param {Object} settings - Full settings object
 * @returns {Promise<Object>} Generated password result
 */
async function generateSinglePassword(mode, commonConfig, settings) {
  switch (mode) {
    case 'syllables':
      return generateSyllables({
        ...commonConfig,
        length: settings.specific.length,
        policy: settings.specific.policy
      });

    case 'passphrase':
      return await generatePassphrase({
        ...commonConfig,
        wordCount: settings.specific.count,
        separator: settings.specific.sep,
        dictionary: settings.specific.dictionary
      });

    case 'leet':
      return generateLeet({
        ...commonConfig,
        baseWord: settings.specific.word
      });

    default:
      throw new Error(`Unknown generation mode: ${mode}`);
  }
}

/**
 * Handles generation results display and notifications
 * @param {Array} results - Array of generated passwords
 * @param {Object} settings - Current settings
 */
function handleGenerationResults(results, settings) {
  if (results.length === 0) {
    showToast('Erreur lors de la génération', 'error');
    return;
  }

  setResults(results);
  renderResults(results, settings.mask);

  const dictText = settings.mode === 'passphrase'
    ? ` (${settings.specific.dictionary})`
    : '';
  const plural = results.length > 1 ? 's' : '';

  showToast(
    `Généré ${results.length} mot${plural} de passe${dictText} !`,
    'success'
  );
}

/**
 * Generate passwords with rate limiting
 * Prevents client-side DoS from excessive generation requests
 * Uses parallel generation with Promise.all for better performance
 */
async function generatePasswords() {
  // Rate limiting check
  const now = Date.now();
  const timeSinceLastGen = now - generationState.lastGeneration;

  // Reset burst counter if window expired
  if (timeSinceLastGen > GENERATION_CONFIG.BURST_WINDOW_MS) {
    generationState.burstCount = 0;
  }

  // Check cooldown for non-burst requests
  if (generationState.burstCount >= GENERATION_CONFIG.MAX_BURST) {
    if (timeSinceLastGen < GENERATION_CONFIG.COOLDOWN_MS) {
      const waitTime = Math.ceil((GENERATION_CONFIG.COOLDOWN_MS - timeSinceLastGen) / 100) / 10;
      showToast(`Génération trop rapide. Veuillez patienter ${waitTime}s`, 'warning');
      safeLog(`Rate limit: ${waitTime}s remaining`);
      return;
    }
    generationState.burstCount = 0; // Reset after cooldown
  }

  // Update state
  generationState.lastGeneration = now;
  generationState.burstCount++;

  try {
    const settings = readSettings();
    const commonConfig = buildCommonConfig(settings);

    // Log visual placement if active
    logVisualPlacement();

    safeLog(`Génération: mode=${settings.mode}, qty=${settings.qty}`);

    // PARALLEL generation instead of sequential for better performance
    const promises = Array.from(
      { length: settings.qty },
      () => generateSinglePassword(settings.mode, commonConfig, settings)
    );

    const allResults = await Promise.all(promises);

    // Filter out errors
    const results = allResults.filter(
      result => result?.value && !result.value.startsWith('error-')
    );

    handleGenerationResults(results, settings);

  } catch (error) {
    safeLog(`Erreur génération: ${error.message}`);
    showToast('Erreur lors de la génération', 'error');
  }
}

async function copyAllPasswords() {
  const results = getResults();
  if (!results?.length) {
    showToast('Aucun mot de passe à copier', 'warning');
    return;
  }

  const passwords = results
    .map(result => result?.value)
    .filter(Boolean)
    .join('\n');

  if (!passwords) {
    showToast('Aucun mot de passe valide trouvé', 'warning');
    return;
  }

  const success = await copyToClipboard(passwords);
  const count = passwords.split('\n').length;

  showToast(
    success
      ? `${count} mot${count > 1 ? 's' : ''} de passe copiés !`
      : 'Impossible de copier les mots de passe',
    success ? 'success' : 'error'
  );

  if (success) {
    safeLog(`Copie groupée: ${count} entrées`);
  }
}

/**
 * Exporte les mots de passe générés vers un fichier
 * Supporte les formats: TXT, JSON, CSV
 */
async function exportPasswords() {
  const results = getResults();
  if (!results?.length) {
    showToast('Aucun mot de passe à exporter', 'warning');
    return;
  }

  // Demander le format d'export
  const format = await promptExportFormat();
  if (!format) return;

  try {
    let content, filename, mimeType;
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);

    switch (format) {
      case 'txt':
        content = results.map(r => r.value).join('\n');
        filename = `genpwd-export-${timestamp}.txt`;
        mimeType = 'text/plain';
        break;

      case 'json':
        content = JSON.stringify({
          exported: new Date().toISOString(),
          generator: 'GenPwd Pro v2.5.1',
          count: results.length,
          passwords: results.map(r => ({
            value: r.value,
            mode: r.mode,
            entropy: r.entropy,
            ...(r.words && { words: r.words }),
            ...(r.dictionary && { dictionary: r.dictionary }),
            ...(r.policy && { policy: r.policy })
          }))
        }, null, 2);
        filename = `genpwd-export-${timestamp}.json`;
        mimeType = 'application/json';
        break;

      case 'csv': {
        const headers = ['Password', 'Mode', 'Entropy (bits)', 'Length', 'Details'];
        const rows = results.map(r => [
          r.value,
          r.mode,
          r.entropy,
          r.value.length,
          r.words ? r.words.join(' ') : (r.baseWord || r.policy || '')
        ]);
        content = [headers, ...rows]
          .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
          .join('\n');
        filename = `genpwd-export-${timestamp}.csv`;
        mimeType = 'text/csv';
        break;
      }

      default:
        showToast('Format non supporté', 'error');
        return;
    }

    // Créer et télécharger le fichier
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast(`Export ${format.toUpperCase()} réussi (${results.length} mots de passe)`, 'success');
    safeLog(`Export réussi: ${filename} (${results.length} entrées)`);

  } catch (error) {
    safeLog(`Erreur export: ${error.message}`);
    showToast('Erreur lors de l\'export', 'error');
  }
}

/**
 * Affiche une boîte de dialogue pour choisir le format d'export
 * @returns {Promise<string|null>} Format choisi ('txt', 'json', 'csv') ou null si annulé
 */
function promptExportFormat() {
  return new Promise((resolve) => {
    const modal = document.createElement('div');
    modal.className = 'modal show';
    modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000;';

    const dialog = document.createElement('div');
    dialog.style.cssText = 'background: var(--bg-secondary, #fff); padding: 2rem; border-radius: 8px; max-width: 400px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);';
    dialog.innerHTML = `
      <h3 style="margin-top: 0; color: var(--text-primary, #333);">Choisir le format d'export</h3>
      <div style="display: flex; flex-direction: column; gap: 1rem; margin: 1.5rem 0;">
        <button id="export-txt" class="btn" style="padding: 0.75rem; cursor: pointer;">
          📄 Texte (.txt) - Simple liste
        </button>
        <button id="export-json" class="btn" style="padding: 0.75rem; cursor: pointer;">
          📊 JSON (.json) - Données complètes
        </button>
        <button id="export-csv" class="btn" style="padding: 0.75rem; cursor: pointer;">
          📈 CSV (.csv) - Excel/Tableur
        </button>
      </div>
      <button id="export-cancel" class="btn btn-secondary" style="width: 100%; padding: 0.75rem; cursor: pointer;">
        Annuler
      </button>
    `;

    modal.appendChild(dialog);
    document.body.appendChild(modal);

    const cleanup = (result) => {
      document.body.removeChild(modal);
      resolve(result);
    };

    dialog.querySelector('#export-txt').addEventListener('click', () => cleanup('txt'));
    dialog.querySelector('#export-json').addEventListener('click', () => cleanup('json'));
    dialog.querySelector('#export-csv').addEventListener('click', () => cleanup('csv'));
    dialog.querySelector('#export-cancel').addEventListener('click', () => cleanup(null));
    modal.addEventListener('click', (e) => {
      if (e.target === modal) cleanup(null);
    });
  });
}

function clearResults() {
  setResults([]);
  renderEmptyState();
  showToast('Résultats effacés', 'info');
}

function runTests() {
  const testsEl = getElement('#tests');
  if (!testsEl) return;
  
  let output = 'Tests système:\n';
  output += '✅ Modules chargés\n';
  output += '✅ DOM initialisé\n';
  output += '✅ Événements bindés\n';
  
  testsEl.textContent = output;
  showToast('Tests exécutés', 'success');
}

// Helpers
function ensurePolicySelection(select) {
  if (!select || !select.options) {
    return;
  }

  const options = Array.from(select.options);
  if (options.length === 0) {
    return;
  }

  const fallback = options.find(option => option.value === 'standard')?.value
    || options[0].value
    || '';

  let desired = select.value;
  const hasDesired = options.some(option => option.value === desired && option.value !== '');

  if (!hasDesired) {
    desired = fallback;
  }

  if (!desired && fallback) {
    desired = fallback;
  }

  if (desired && select.value !== desired) {
    select.value = desired;
  }
}

function resetBlocksForCurrentMode() {
  const settings = readSettings();
  let param = 20;

  if (settings.mode === 'syllables') {
    param = parseInt(getElement('#syll-len')?.value || '20', 10);
  } else if (settings.mode === 'passphrase') {
    param = parseInt(getElement('#pp-count')?.value || '5', 10);
  } else if (settings.mode === 'leet') {
    const word = settings.specific?.word || '';
    param = word.length || 1;
  }

  const blocks = defaultBlocksForMode(settings.mode, param);
  setBlocks(blocks);
  renderBlocksUI();
  setUIState('blockDirty', false);
}

function renderBlocksUI() {
  const blocks = getBlocks();
  renderChips('#chips', blocks, (index) => {
    const currentBlocks = getBlocks();
    const current = currentBlocks[index];
    currentBlocks[index] = current === 'U' ? 'l' : current === 'l' ? 'T' : 'U';
    setBlocks(currentBlocks);
    setUIState('blockDirty', true);
    renderBlocksUI();
    debouncedUpdatePreview();
  });
  
  updateBlockSizeLabel('#block-size-label', blocks.length);
}

function initializeBlockSyncState() {
  const caseMode = getElement('#case-mode-select')?.value || 'mixte';
  setUIState('useBlocks', caseMode === 'blocks');

  const toggle = getElement('#blocks-sync-toggle');
  if (toggle) {
    setUIState('blockAutoSync', toggle.checked !== false);
  }

  if (caseMode === 'blocks') {
    scheduleCurrentModeBlockSync();
  }
}

function scheduleCurrentModeBlockSync() {
  const mode = getElement('#mode-select')?.value || 'syllables';
  if (mode === 'syllables') {
    const length = parseInt(getElement('#syll-len')?.value || '0', 10);
    scheduleBlockSync('syllables', length);
  } else if (mode === 'passphrase') {
    const count = parseInt(getElement('#pp-count')?.value || '0', 10);
    scheduleBlockSync('passphrase', count);
  }
}

function scheduleBlockSync(mode, value) {
  if (!getUIState('blockAutoSync') || !getUIState('useBlocks')) {
    return;
  }

  if (getUIState('blockDirty')) {
    return;
  }

  const numericValue = Number(value);
  if (!Number.isFinite(numericValue) || numericValue <= 0) {
    return;
  }

  if (blockSyncTimeout) {
    clearTimeout(blockSyncTimeout);
  }

  blockSyncTimeout = setTimeout(() => {
    syncBlocksWithLength(mode, numericValue);
  }, BLOCK_SYNC_DELAY);
}

function syncBlocksWithLength(mode, value) {
  if (!getUIState('blockAutoSync') || !getUIState('useBlocks') || getUIState('blockDirty')) {
    return;
  }

  let targetBlocks;

  switch (mode) {
    case 'syllables':
      targetBlocks = Math.max(2, Math.min(6, Math.ceil(value / 4)));
      break;
    case 'passphrase':
      targetBlocks = Math.max(1, Math.min(6, value));
      break;
    default:
      return;
  }

  const patterns = ['T', 'l', 'U'];
  const newBlocks = Array.from({ length: targetBlocks }, (_, index) => patterns[index % patterns.length]);

  const current = getBlocks();
  const isIdentical = current.length === newBlocks.length && current.every((token, index) => token === newBlocks[index]);
  if (isIdentical) {
    return;
  }

  setBlocks(newBlocks);
  renderBlocksUI();
  setUIState('blockDirty', false);
  safeLog(`Blocs synchronisés: ${newBlocks.join('-')} (${targetBlocks} blocs)`);
}

function debouncedUpdatePreview() {
  if (previewTimeout) {
    clearTimeout(previewTimeout);
  }
  previewTimeout = setTimeout(updatePreview, 150);
}

function updatePreview() {
  // Implementation simplifiée de la prévisualisation
  const settings = readSettings();
  if (settings.caseMode !== 'blocks') return;
  
  const blocks = getBlocks();
  const preview = `${blocks.join('-')} • Pattern de casse`;
  
  const previewEl = getElement('#case-preview');
  if (previewEl) {
    previewEl.textContent = preview;
  }
}


// === js/ui/render.js ===
/*
 * Copyright 2025 Julien Bombled
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// src/js/ui/render.js - Rendu des résultats et cartes





const clickTimers = new WeakMap();
let eventController = new AbortController();

function renderResults(results, mask) {
  const wrap = getElement('#results-list');
  if (!wrap) return;

  try {
    cleanupPasswordListeners();
    wrap.innerHTML = '';

    if (!Array.isArray(results) || results.length === 0) {
      wrap.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🔐</div>
          <p>Cliquez sur "Générer" pour créer vos mots de passe</p>
        </div>`;
      return;
    }

    results.forEach((item, idx) => {
      const { value } = item;
      if (typeof value !== 'string') return;

      const card = createPasswordCard(item, idx + 1, mask);
      wrap.appendChild(card);
    });

    bindPasswordClickEvents();
  } catch (e) {
    safeLog(`Erreur renderResults: ${e.message}`);
  }
}

function createPasswordCard(item, id, mask) {
  const { value, entropy, mode, dictionary } = item;
  const counts = compositionCounts(value);
  const total = value.length || 1;
  
  // Calcul des segments pour la barre de composition
  const segU = Math.round(counts.U / total * 1000) / 10;
  const segL = Math.round(counts.L / total * 1000) / 10;
  const segD = Math.round(counts.D / total * 1000) / 10;
  const segS = Math.round(counts.S / total * 1000) / 10;

  // Information sur le dictionnaire
  const dictInfo = mode === 'passphrase' && dictionary ? 
    `${dictionary.charAt(0).toUpperCase() + dictionary.slice(1)}` : 
    mode || 'unknown';

  const card = document.createElement('div');
  card.className = 'card';
  card.innerHTML = `
    <div class="card-sec card-header">
      <div class="id">#${id}</div>
      <span class="spacer"></span>
      <div class="stat"><span class="dot"></span><strong>${(entropy || 0).toFixed(1)}</strong>&nbsp;bits</div>
      <div class="len">${total} chars</div>
    </div>
    <div class="card-sec pwd ${mask ? 'masked' : ''}" data-index="${id-1}" data-password="${escapeHtml(value)}" title="Cliquer pour copier • Double-clic pour afficher/masquer">
      <div class="value mono">${escapeHtml(value)}</div>
      <div class="actions">
        <svg class="copy-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
          <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
        </svg>
        <span>Copier</span>
      </div>
    </div>
    <div class="card-sec comp">
      <div class="comp-bar">
        ${segU > 0 ? `<div class="seg u" style="width:${segU}%"></div>` : ''}
        ${segL > 0 ? `<div class="seg l" style="width:${segL}%"></div>` : ''}
        ${segD > 0 ? `<div class="seg d" style="width:${segD}%"></div>` : ''}
        ${segS > 0 ? `<div class="seg s" style="width:${segS}%"></div>` : ''}
      </div>
      <div class="comp-legend">
        <span class="legend-item"><span class="legend-dot" style="background:var(--accent-blue)"></span>${counts.U} MAJ</span>
        <span class="legend-item"><span class="legend-dot" style="background:var(--accent-purple)"></span>${counts.L} min</span>
        <span class="legend-item"><span class="legend-dot" style="background:var(--accent-yellow)"></span>${counts.D} chiffres</span>
        <span class="legend-item"><span class="legend-dot" style="background:var(--accent-green)"></span>${counts.S} spé</span>
      </div>
    </div>
    <div class="card-sec info"><div>Mode: ${dictInfo}</div><div>CLI-Safe: ✓</div></div>
  `;

  return card;
}

function bindPasswordClickEvents() {
  const passwordElements = document.querySelectorAll('.pwd');

  passwordElements.forEach(el => {
    el.addEventListener('click', async (e) => {
      e.preventDefault();
      
      const existingTimer = clickTimers.get(el);
      if (existingTimer) {
        clearTimeout(existingTimer);
        clickTimers.delete(el);
        
        // Double-clic : basculer masquage
        el.classList.toggle('masked');
        const actionsEl = el.querySelector('.actions span');
        if (actionsEl) {
          actionsEl.textContent = 'Copier';
        }
        return;
      }

      // Simple clic : programmer la copie
      const timer = setTimeout(async () => {
        clickTimers.delete(el);
        
        const password = el.getAttribute('data-password');
        if (password) {
          el.classList.add('copying');
          
          const success = await copyToClipboard(password);
          if (success) {
            showToast('Mot de passe copié !', 'success');
            safeLog(`Copié: ${password.substring(0, 8)}...`);
          } else {
            showToast('Erreur lors de la copie', 'error');
          }
          
          setTimeout(() => {
            el.classList.remove('copying');
          }, 600);
        }
      }, 250);

      clickTimers.set(el, timer);
    }, { signal: eventController.signal });
  });

  safeLog(`Bound click events to ${passwordElements.length} password cards`);
}

/**
 * Cleanup all password card event listeners
 * Uses AbortController for automatic removal of all tracked listeners
 * Also clears any pending click timers
 */
function cleanupPasswordListeners() {
  // Abort all listeners registered with the current controller
  eventController.abort();

  // Create new controller for next batch of listeners
  eventController = new AbortController();

  // Clear any pending click timers
  document.querySelectorAll('.pwd').forEach(el => {
    const timer = clickTimers.get(el);
    if (timer) {
      clearTimeout(timer);
      clickTimers.delete(el);
    }
  });

  safeLog('Password card listeners cleaned up');
}

function updateMaskDisplay(mask) {
  document.querySelectorAll('.pwd').forEach(el => {
    el.classList.toggle('masked', mask);
  });
}

function renderEmptyState() {
  const wrap = getElement('#results-list');
  if (wrap) {
    wrap.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🔐</div>
        <p>Cliquez sur "Générer" pour créer vos mots de passe</p>
      </div>`;
  }
}


// === js/ui/modal.js ===
/*
 * Copyright 2025 Julien Bombled
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// src/js/ui/modal.js - Gestion des modaux et overlays


function showAboutModal() {
  const modal = getElement('#about-modal');
  if (modal) {
    modal.classList.add('show');
    
    // Focus management pour accessibilité
    const closeBtn = getElement('#modal-close');
    if (closeBtn) closeBtn.focus();
    
    // Empêcher scroll body
    document.body.style.overflow = 'hidden';
    
    safeLog('Modal À Propos ouvert');
  }
}

function hideAboutModal() {
  const modal = getElement('#about-modal');
  if (modal) {
    modal.classList.remove('show');
    
    // Restaurer scroll body
    document.body.style.overflow = '';
    
    // Retourner focus au bouton
    const aboutBtn = getElement('#btn-about');
    if (aboutBtn) aboutBtn.focus();
    
    safeLog('Modal À Propos fermé');
  }
}

function bindModalEvents() {
  // Ouvrir modal
  addEventListener(getElement('#btn-about'), 'click', showAboutModal);
  
  // Fermer modal - bouton
  addEventListener(getElement('#modal-close'), 'click', hideAboutModal);
  
  // Fermer modal - clic overlay
  addEventListener(getElement('#about-modal'), 'click', (e) => {
    if (e.target === e.currentTarget) {
      hideAboutModal();
    }
  });
  
  // Fermer modal - touche Escape
  addEventListener(document, 'keydown', (e) => {
    if (e.key === 'Escape' && getElement('#about-modal').classList.contains('show')) {
      hideAboutModal();
    }
  });
  
  safeLog('Événements modal bindés');
}


// === js/app.js ===
/*
 * Copyright 2025 Julien Bombled
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// src/js/app.js - Point d'entrée principal de l'application












window.GenPwdApp = class GenPwdApp {
  constructor() {
    this.initialized = false;
    this.version = '2.5.2';
  }

  async init() {
    try {
      safeLog(`Démarrage GenPwd Pro v${this.version} - Architecture modulaire`);

      // 0. Initialiser le système de thèmes (en premier pour l'UI)
      initThemeSystem();
      safeLog('Système de thèmes initialisé');

      // 1. Initialiser le monitoring d'erreurs
      initErrorMonitoring();
      safeLog('Monitoring d\'erreurs initialisé');

      // 2. Validation de l'environnement
      if (!this.validateEnvironment()) {
        throw new Error('Environnement non compatible');
      }

      // 3. Validation des données critiques
      if (!validateCharSets()) {
        throw new Error('Données CHAR_SETS corrompues');
      }

      // 4. Initialisation DOM
      await initializeDOM();
      safeLog('DOM initialisé');

      // 5. Initialisation dictionnaires
      initializeDictionaries();
      safeLog('Système dictionnaires initialisé');

      // 6. Configuration initiale des blocs
      const initialBlocks = defaultBlocksForMode('syllables');
      setBlocks(initialBlocks);
      safeLog(`Blocs initialisés: ${initialBlocks.join('-')}`);

      // 7. Binding des événements
      bindEventHandlers();
      bindModalEvents();
      safeLog('Événements bindés');

      // 8. Génération initiale après un délai
      setTimeout(() => this.generateInitial(), 300);

      this.initialized = true;
      safeLog('Application initialisée avec succès');

    } catch (error) {
      console.error('Erreur critique initialisation:', error);
      safeLog(`Erreur critique: ${error.message}`);
      reportError(error, { phase: 'initialization' });
      showToast('Erreur critique au démarrage', 'error');
    }
  }

  validateEnvironment() {
    // Vérifier APIs de window
    const windowAPIs = ['fetch', 'Promise', 'Map', 'Set', 'JSON'];
    
    for (const api of windowAPIs) {
      if (typeof window[api] === 'undefined') {
        safeLog(`API window manquante: ${api}`);
        return false;
      }
    }
    
    // Vérifier APIs spécifiques
    if (typeof Object.assign === 'undefined') {
      safeLog('API manquante: Object.assign');
      return false;
    }
    
    if (typeof document.querySelector === 'undefined') {
      safeLog('API manquante: document.querySelector');
      return false;
    }
    
    if (typeof window.addEventListener === 'undefined') {
      safeLog('API manquante: window.addEventListener');
      return false;
    }

    // Vérifier support CSS Grid
    const testEl = document.createElement('div');
    testEl.style.display = 'grid';
    if (testEl.style.display !== 'grid') {
      safeLog('CSS Grid non supporté');
      return false;
    }

    safeLog('Environnement validé avec succès');
    return true;
  }

  async generateInitial() {
    try {
      safeLog('Lancement génération automatique...');
      
      // Simuler clic sur le bouton générer
      const generateBtn = document.getElementById('btn-generate');
      if (generateBtn) {
        generateBtn.click();
      } else {
        safeLog('Bouton générer non trouvé pour génération initiale');
      }
      
    } catch (error) {
      safeLog(`Erreur génération initiale: ${error.message}`);
    }
  }
}

// Initialisation automatique
document.addEventListener('DOMContentLoaded', () => {
  window.genPwdApp = new GenPwdApp();
  window.genPwdApp.init();
});

// Note: La gestion des erreurs globales est maintenant gérée par error-monitoring.js
// qui est initialisé dans init() via initErrorMonitoring()



// ============================================================================
// INITIALISATION AUTOMATIQUE
// ============================================================================

function initGenPwdApp() {
  try {
    if (typeof GenPwdApp !== 'undefined') {
      window.genPwdApp = new GenPwdApp();
      window.genPwdApp.init();
    } else {
      console.error('GenPwdApp non trouvé');
    }
  } catch (error) {
    console.error('Erreur initialisation:', error);
  }
}

// Démarrage automatique
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initGenPwdApp);
} else {
  initGenPwdApp();
}

})(); // Fin IIFE
